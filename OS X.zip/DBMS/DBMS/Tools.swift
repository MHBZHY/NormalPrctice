//
//  Tools.swift
//  DBMS
//
//  Created by zhy on 16/3/19.
//  Copyright © 2016年 zhy. All rights reserved.
//

import Foundation

var voidClosure: () -> Void = {}

extension NSTimer {
    public class func scheduledTimerWithTimeInterval(ti: NSTimeInterval, userInfo: AnyObject?, repeats: Bool, action: () -> Void) -> NSTimer {
        voidClosure = action
        return self.scheduledTimerWithTimeInterval(ti, target: self, selector: #selector(NSTimer.timerSelector), userInfo: userInfo, repeats: repeats)
    }
    
    func timerSelector() {
        voidClosure()
    }
}