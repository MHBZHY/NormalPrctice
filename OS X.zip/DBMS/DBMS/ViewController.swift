//
//  ViewController.swift
//  DBMS
//
//  Created by zhy on 16/3/17.
//  Copyright © 2016年 zhy. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {
    
    @IBOutlet weak var mainTableView: NSTableView!
    
    var dataSource: [[String: AnyObject]]?
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        dataSource = DBMSModel.loadFromFile("DBMSDemo.db")
        
        if dataSource == nil {
            dataSource = [[String: AnyObject]]()
        }
        
        
        
    }

    override var representedObject: AnyObject? {
        didSet {
        // Update the view, if already loaded.
        }
    }

    
    @IBAction func addRow(sender: NSButton) {
        dataSource!.append(DBMSModel(time: "2015-12-24", money: 1000.00, payType: "购物", payPlace: "Internet").contentData)
        mainTableView.reloadData()
        
        DBMSModel.saveToFile("DBMSDemo.db", dataToSave: dataSource!)
    }
    
    
    @IBAction func removeRow(sender: NSButton) {
        dataSource!.removeAtIndex(mainTableView.selectedRow)
        mainTableView.reloadData()
        
        DBMSModel.saveToFile("DBMSDemo.db", dataToSave: dataSource!)
    }
    
    
    @IBAction func findMin(sender: NSButton) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)) {
            var minRow: [String: AnyObject] = self.dataSource![0]
            
            for row in self.dataSource! {
                if minRow["money"]!.floatValue > row["money"]!.floatValue {
                    minRow = row
                }
                
            }
            
            dispatch_async(dispatch_get_main_queue(), { 
                self.dataSource = [minRow]
                self.mainTableView.reloadData()
            })
        }
    }
    
    
    @IBAction func findMax(sender: NSButton) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)) {
            var maxRow: [String: AnyObject] = self.dataSource![0]
            
            for row in self.dataSource! {
                if maxRow["money"]!.floatValue < row["money"]!.floatValue {
                    maxRow = row
                }
                
            }
            
            dispatch_async(dispatch_get_main_queue(), {
                self.dataSource = [maxRow]
                self.mainTableView.reloadData()
            })
        }
    }
    
    
    @IBAction func loadFile(sender: NSButton) {
//        dataSource = DBMSModel.readTXTFile("~/Desktop/test_01.txt")
//        mainTableView.reloadData()
    }
}

extension ViewController: NSTableViewDataSource, NSTableViewDelegate {
    
    //MARK: - tableview方法
    func numberOfRowsInTableView(tableView: NSTableView) -> Int {
        return dataSource!.count
    }
    
    func tableView(tableView: NSTableView, objectValueForTableColumn tableColumn: NSTableColumn?, row: Int) -> AnyObject? {
        
        return dataSource![row][tableColumn!.identifier]
    }
    
    
    func tableView(tableView: NSTableView, setObjectValue object: AnyObject?, forTableColumn tableColumn: NSTableColumn?, row: Int) {
        
        dataSource![row][tableColumn!.identifier] = object
        
        
        tableView.reloadData()
        
        
        DBMSModel.saveToFile("DBMSDemo.db", dataToSave: dataSource!)
    }
    
}

