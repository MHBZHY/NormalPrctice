//
//  SearchViewController.swift
//  DBMS
//
//  Created by zhy on 16/3/23.
//  Copyright © 2016年 zhy. All rights reserved.
//

import Cocoa

class SearchViewController: NSViewController, NSTextFieldDelegate {
    
    @IBOutlet weak var mainSearchTextField: NSTextField!
    var superWindow: NSWindow!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
        
        mainSearchTextField.delegate = self
    }
    
    
    @IBAction func textChanged(sender: NSTextField) {
        
    }
}
