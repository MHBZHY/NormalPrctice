//
//  GenerateViewController.swift
//  DBMS
//
//  Created by zhy on 16/3/19.
//  Copyright © 2016年 zhy. All rights reserved.
//

import Cocoa

class GenerateViewController: NSViewController {

    @IBOutlet weak var mainTableView: NSTableView!
    
    @IBOutlet weak var baseScrollView: NSScrollView!
    
    var num: Int!
    
    var numOfRecordsPerRefresh: Int!
    
//    var modelsCount: Int = 0
    
    var models = [[String: AnyObject]]()
    
    let payType = ["购物", "旅游", "上网", "饮食"]
    
    let place = ["王府井", "西单大悦城", "凯德Mall", "中关村"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
        
    }
    
    override func viewDidAppear() {
        super.viewDidAppear()
        
        let startTime = NSDate().timeIntervalSince1970
        
        numOfRecordsPerRefresh = (self.num > 500) ? 500 : self.num
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)) { () -> Void in
            
            var endTime: NSTimeInterval!
            
            let formatter = NSDateFormatter()
            formatter.dateFormat = "yyyy-MM-dd"
            
            for i in 1...self.num {
                //generate
                
                self.models.append(DBMSModel(time: self.generateTime(NSTimeInterval(i), formatter: formatter), money: Float(i), payType: self.payType[i % 4], payPlace: self.place[i % 4]).contentData)
                
                endTime = NSDate().timeIntervalSince1970
                
                if i > self.numOfRecordsPerRefresh {
                    if i % self.numOfRecordsPerRefresh == 0 {
                        dispatch_async(dispatch_get_main_queue(), { () -> Void in
//                            self.modelsCount = self.models.count
                            self.mainTableView.reloadData()
                            
                            self.mainTableView.scrollToEndOfDocument(nil)
                        })
                    }
                }
                
                
                
            }
            
            
            let startTime1 = NSDate().timeIntervalSince1970
            
            
            var money: Float = 0
            for model in self.models {
                money += model["money"]!.floatValue
            }
            
            let endTime1 = NSDate().timeIntervalSince1970
            
            print("avg: \(money / Float(self.models.count))\n time: \(endTime1 - startTime1)")
            
            
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                self.mainTableView.reloadData()
                self.performSegueWithIdentifier("ResultAlert", sender: endTime - startTime)
            })
        }
    }
    
    
    func generateTime(seed: NSTimeInterval, formatter: NSDateFormatter) -> String {
        return formatter.stringFromDate(NSDate(timeInterval: 86400 * seed, sinceDate: NSDate(timeIntervalSince1970: 0)))
    }
    
    
    override func prepareForSegue(segue: NSStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "ResultAlert" {
            let dest = (segue.destinationController as! NSWindowController).contentViewController as! AlertViewController
            
            dest.time = sender as! NSTimeInterval
        }
    }
}


extension GenerateViewController: NSTableViewDataSource, NSTableViewDelegate {
    func numberOfRowsInTableView(tableView: NSTableView) -> Int {
        return self.models.count
    }
    
    func tableView(tableView: NSTableView, objectValueForTableColumn tableColumn: NSTableColumn?, row: Int) -> AnyObject? {
        return models[row][tableColumn!.identifier]
    }
}