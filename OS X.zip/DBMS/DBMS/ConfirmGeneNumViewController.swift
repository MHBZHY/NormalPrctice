//
//  ConfirmGeneNumViewController.swift
//  DBMS
//
//  Created by zhy on 16/3/22.
//  Copyright © 2016年 zhy. All rights reserved.
//

import Cocoa

class ConfirmGeneNumViewController: NSViewController {
    
    @IBOutlet weak var numTextField: NSTextField!
    
    var num: Int!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
        
    }
    
    
    @IBAction func startGeneRecords(sender: NSButton) {
        self.performSegueWithIdentifier("StartGeneRecords", sender: Int(numTextField.stringValue))
        self.view.window!.close()
    }
    
    override func prepareForSegue(segue: NSStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "StartGeneRecords" {
            let des = (segue.destinationController as! NSWindowController).contentViewController as! GenerateViewController
            
            des.num = sender as! Int
        }
    }
}
