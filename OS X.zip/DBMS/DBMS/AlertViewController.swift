//
//  AlertViewController.swift
//  DBMS
//
//  Created by zhy on 16/3/19.
//  Copyright © 2016年 zhy. All rights reserved.
//

import Cocoa

class AlertViewController: NSViewController {
    
    @IBOutlet weak var timeLabel: NSTextField!
    
    
    var time: NSTimeInterval!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
        
//        timeLabel.stringValue = "Used Time: " + String(time)
    }
    
    override func viewDidAppear() {
        super.viewDidAppear()
        
        timeLabel.stringValue = "Used Time: " + String(time)
    }
    
    @IBAction func OKAction(sender: NSButton) {
        self.view.window!.close()
    }
}
