//
//  AppDelegate.swift
//  DBMS
//
//  Created by zhy on 16/3/17.
//  Copyright © 2016年 zhy. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

    var mainWindow: NSWindow!
    let storyboard = NSStoryboard(name: "Main", bundle: NSBundle.mainBundle())

    func applicationDidFinishLaunching(aNotification: NSNotification) {
        // Insert code here to initialize your application
        
        mainWindow = NSApplication.sharedApplication().windows[0]
        
    }

    func applicationWillTerminate(aNotification: NSNotification) {
        // Insert code here to tear down your application
    }

    func applicationShouldHandleReopen(sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        if !flag {
            mainWindow.makeKeyAndOrderFront(nil)
        }
        
        return true
    }
    
    @IBAction func find(sender: NSMenuItem) {
        let windowAsSheet = (storyboard.instantiateControllerWithIdentifier("SearchController") as! NSWindowController).window!
        
        (windowAsSheet.contentViewController as! SearchViewController).superWindow = mainWindow
        
        mainWindow.beginSheet(windowAsSheet) { (res) in
            print("hehe")
        }
    }
    
}

