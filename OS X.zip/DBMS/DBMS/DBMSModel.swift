//
//  DBMSModel.swift
//  DBMS
//
//  Created by zhy on 16/3/17.
//  Copyright © 2016年 zhy. All rights reserved.
//

import Cocoa
import AppKit


public class DBMSModel: NSObject {
    var contentData = [String: AnyObject]()
    
    override init() {}
    
    init(time: String!, money: Float!, payType: String!, payPlace: String!) {
        contentData["time"] = time
        contentData["money"] = money
        contentData["target"] = payType
        contentData["place"] = payPlace
    }
    
    
    public class func loadFromFile(path: String) -> [[String: AnyObject]]? {
        let data = NSData(contentsOfFile: path)
        
        if data == nil {
            return nil
        }
        else {
            return NSKeyedUnarchiver.unarchiveObjectWithData(data!) as? [[String: AnyObject]]
        }
    }
    
    public func encodeWithCoder(aCoder: NSCoder) {
        
    }
    
    public required init?(coder aDecoder: NSCoder) {
        
    }
    
    public class func saveToFile(path: String, dataToSave models: [[String: AnyObject]]) {
        let data: NSData = NSKeyedArchiver.archivedDataWithRootObject(models)
        
        data.writeToFile(path, atomically: true)
    }
    
//    public class func readTXTFile(path: String) -> [[String: AnyObject]]? {
//        let data = NSData(contentsOfFile: path)
//        let content = [[String: AnyObject]]()
//        
//        let str = NSString(data: data!, encoding: NSUTF8StringEncoding) as! String
//        
//        let arr = str.characters.split("\t")
//        
//        for i in 0..<(arr.count / 3) {
//
//        }
//    }
}



