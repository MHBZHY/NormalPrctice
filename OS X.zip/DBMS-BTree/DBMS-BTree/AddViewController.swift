//
//  AddViewController.swift
//  DBMS-BTree
//
//  Created by zhy on 16/4/13.
//  Copyright © 2016年 zhy. All rights reserved.
//

import Cocoa

class AddViewController: NSViewController {
	
	
	@IBOutlet weak var timeTextField: NSTextField!
	
	@IBOutlet weak var moneyTextField: NSTextField!
	
	@IBOutlet weak var targetTextField: NSTextField!
	
	@IBOutlet weak var placeTextField: NSTextField!
	

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
		
		
    }
    
	@IBAction func confirm(sender: AnyObject) {
		
		let model = DBMSModel(time: timeTextField.stringValue, money: Float(moneyTextField.stringValue), payType: targetTextField.stringValue, payPlace: placeTextField.stringValue)
		
		NSNotificationCenter.defaultCenter().postNotificationName("AddRecord", object: model)
	}
}
