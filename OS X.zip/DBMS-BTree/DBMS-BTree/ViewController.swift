//
//  ViewController.swift
//  DBMS-BTree
//
//  Created by zhy on 16/4/5.
//  Copyright © 2016年 zhy. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    @IBOutlet weak var textField: NSTextField!
	@IBOutlet weak var tableView: NSTableView!
    
    var tree = BTree()
	var models = [[String: AnyObject]]()
	
	var stableModels = [[String: AnyObject]]()
	
	var modelIndex: IntMax?
	
	let openPanel = NSOpenPanel()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
		
		NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(receivedRecord(_:)), name: "AddRecord", object: nil)
    }

    override var representedObject: AnyObject? {
        didSet {
        // Update the view, if already loaded.
        }
    }

	override func viewDidAppear() {
		super.viewDidAppear()

		print("view appeared")
	}


    @IBAction func Search(sender: NSButton) {
        let time = IntMax(textField.stringValue)
        
		modelIndex = tree.search(presentRoot: tree.root, key: time!)
		
		models.removeAll()
		models.append(stableModels[Int(modelIndex!)])
		
		tableView.reloadData()
    }
	
	
	@IBAction func loadFromFile(sender: NSButton) {
		
		
		openPanel.canChooseDirectories = true
		openPanel.canChooseFiles = true
		openPanel.allowsMultipleSelection = false
		
		openPanel.directoryURL = NSBundle(path: "~/Desktop")?.bundleURL
		
		openPanel.beginSheetModalForWindow(self.view.window!) { (num) in
			if num == NSFileHandlingPanelOKButton {
				//加载record
				self.models = DBMSModel.loadFormTXTFile(self.openPanel.URL!)!
				
				//拼接btree路径
				var path = self.openPanel.URL!.absoluteString
				path.insertContentsOf("_index".characters, at: path.endIndex.advancedBy(-4))
				
				//加载btree
				self.tree.readFromFile(filePath:  NSURL(string: path)!)
				
				//加载完毕刷新列表
				self.tableView.reloadData()
				self.tableView.scrollToEndOfDocument(nil)
				
				self.stableModels = self.models
			}
		}
	}
	
	
	@IBAction func reload(sender: NSButton) {
		models = stableModels
		
		tableView.reloadData()
	}
	
	func receivedRecord(noti: NSNotification) -> Void {
		let data: [String : AnyObject] = (noti.object as! DBMSModel).contentData
		
		stableModels.append(data)
		
		tree.addKey(IntMax(data["time"] as! String)!, position: IntMax(stableModels.count - 1), specificNode: nil, newChildNode: nil)
		
		models = stableModels
		
		tableView.reloadData()
	}
	
	@IBAction func save(sender: AnyObject) {
		openPanel.canChooseDirectories = true
		openPanel.canChooseFiles = true
		openPanel.allowsMultipleSelection = false
		
		openPanel.directoryURL = NSBundle(path: "~/Desktop")?.bundleURL
		
		openPanel.beginSheetModalForWindow(self.view.window!) { (num) in
			if num == NSFileHandlingPanelOKButton {
				self.tree.writeDataToFile(self.openPanel.URL!)
			}
		}
		
		
	}
}


extension ViewController: NSTableViewDataSource, NSTableViewDelegate {
	
	func numberOfRowsInTableView(tableView: NSTableView) -> Int {
		return self.models.count
	}
	
	func tableView(tableView: NSTableView, objectValueForTableColumn tableColumn: NSTableColumn?, row: Int) -> AnyObject? {
		return models[row][tableColumn!.identifier]
	}
}
