//
//  DBMSModel.swift
//  DBMS
//
//  Created by zhy on 16/3/17.
//  Copyright © 2016年 zhy. All rights reserved.
//

import Cocoa
import AppKit


public class DBMSModel: NSObject {
    var contentData = [String: AnyObject]()
    
    override init() {}
    
    init(time: String!, money: Float!, payType: String!, payPlace: String!) {
        contentData["time"]   = time
        contentData["money"]  = money
        contentData["target"] = payType
        contentData["place"]  = payPlace
    }
	
	
	init(fileURL URL: NSURL) {
		do {
			let strs = try String(contentsOfURL: URL).componentsSeparatedByCharactersInSet(NSCharacterSet.newlineCharacterSet())
			
			for str in strs {
				let contents = str.componentsSeparatedByCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
				
				
				contentData["time"]   = contents[0]
				contentData["money"]  = contents[1]
				contentData["target"] = contents[2]
				contentData["place"]  = contents[3]
			}
			
		} catch {}
	}
    
    
    public class func loadFromFile(path: String) -> [[String: AnyObject]]? {
        let data = NSData(contentsOfFile: path)
        
        if data == nil {
            return nil
        }
        else {
            return NSKeyedUnarchiver.unarchiveObjectWithData(data!) as? [[String: AnyObject]]
        }
    }
	
	
	//MARK: - 加载文本文件
	public class func loadFormTXTFile(path: NSURL) -> [[String: AnyObject]]? {
		var datas = [[String: AnyObject]]()
		
		do {
			let lines = try String(contentsOfURL: path).componentsSeparatedByCharactersInSet(NSCharacterSet.newlineCharacterSet())
			
			for line in lines {
				let strs = line.componentsSeparatedByCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
				
				let data = [
					"time": strs[0],
					"money": strs[1],
					"target": strs[2],
					"place": strs[3]
				]
				
				datas.append(data)
			}
			
		} catch {}
		
		return datas
	}
	
    
    public func encodeWithCoder(aCoder: NSCoder) {
        
    }
    
    public required init?(coder aDecoder: NSCoder) {
        
    }
    
    public class func saveToFile(path: String, dataToSave models: [[String: AnyObject]]) {
        let data: NSData = NSKeyedArchiver.archivedDataWithRootObject(models)
        
        data.writeToFile(path, atomically: true)
    }
	
	
	public class func saveToTXTFile(path: NSURL, datas: [[String: AnyObject]]) {
	}
	
	public class func dataToSave(data: [String: AnyObject]) -> NSData {
		let line = "\(data["time"]!) \(data["money"]!) \(data["target"]!) \(data["place"]!)\n"
		
		return line.dataUsingEncoding(NSUTF8StringEncoding)!
	}
	
}



