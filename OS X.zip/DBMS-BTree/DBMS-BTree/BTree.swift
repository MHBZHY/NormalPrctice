//
//  BTree.swift
//  DBMS-BTree
//
//  Created by zhy on 16/4/5.
//  Copyright © 2016年 zhy. All rights reserved.
//

import Foundation


public class BTree: NSObject, NSCoding {
    
    var MAX_KEY_NUM = 4
	
	var ITEM_NUM = 0
	
	
	//根节点
	var root: BTreeNode!
	
	
	class BTreeNode: NSObject, NSCoding {
		//键
        var keys = [IntMax]()
		//值
		var datas = [IntMax]()
		//子树
        var pointers = [BTreeNode?]()
		//父节点
		var father: BTreeNode?
		
		func encodeWithCoder(aCoder: NSCoder) {
			aCoder.encodeObject(NSValue(bytes: &keys, objCType: "[IntMax]"), forKey: "keys")
			aCoder.encodeObject(NSValue(bytes: &datas, objCType: "[IntMax]"), forKey: "datas")
			aCoder.encodeObject(NSValue(bytes: &pointers, objCType: "[IntMax]"), forKey: "pointers")
			aCoder.encodeObject(father, forKey: "father")
		}
		
		override init() {}
	
		init(keys: [IntMax], pointers: [BTreeNode?], father: BTreeNode?, recordPosition datas: [IntMax]) {
            self.keys     = keys
            self.pointers = pointers
            self.father   = father
            self.datas    = datas
        }
		
		
		required init(coder aDecoder: NSCoder) {
			(aDecoder.decodeObjectForKey("keys") as! NSValue).getValue(&self.keys)
			(aDecoder.decodeObjectForKey("datas") as! NSValue).getValue(&self.datas)
			(aDecoder.decodeObjectForKey("pointers") as! NSValue).getValue(&self.pointers)
			self.father = aDecoder.decodeObjectForKey("father") as? BTreeNode
		}
    }
	
	public func encodeWithCoder(aCoder: NSCoder) {
		aCoder.encodeObject(MAX_KEY_NUM, forKey: "key_num")
		aCoder.encodeObject(ITEM_NUM, forKey: "item_num")
		aCoder.encodeObject(root, forKey: "root")
	}
	
	public required init(coder aDecoder: NSCoder) {
		MAX_KEY_NUM = aDecoder.decodeObjectForKey("key_num") as! Int
		ITEM_NUM = aDecoder.decodeObjectForKey("item_num") as! Int
		root = aDecoder.decodeObjectForKey("root") as! BTreeNode
	}
	
	
	func writeDataToFile(path: NSURL) -> Void {
		let pathStr = path.absoluteString
		
		var subpath = pathStr.substringFromIndex(pathStr.startIndex.advancedBy(7))
		subpath.insertContentsOf("_b_index".characters, at: subpath.endIndex.advancedBy(-4))
		
		NSKeyedArchiver.archiveRootObject(self, toFile: subpath)
	}
    
	
    
    override init() {
        self.root = BTreeNode(keys: [], pointers: [nil], father: nil, recordPosition: [])
    }
	
	
	//MARK: - 从文件中加载
	func readFromFile(filePath path: NSURL) -> Void {
		self.root = BTreeNode(keys: [], pointers: [nil], father: nil, recordPosition: [])
		
		let strs: [String]?
		
		do {
			strs = try String(contentsOfURL: path).componentsSeparatedByCharactersInSet(NSCharacterSet.newlineCharacterSet())
			
			for line in strs! {
				
				let nodeStrs = line.componentsSeparatedByCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
				
				addKey(IntMax(nodeStrs[0])!, position: IntMax(nodeStrs[1])!, specificNode: nil, newChildNode: nil)
				
				ITEM_NUM += 1
			}
		}
		catch {}
		
		print("complete")
	}
	
    
    //MARK: - 添加索引
	func addKey(key: IntMax, position pos: IntMax, specificNode: BTreeNode?, newChildNode: BTreeNode?) {
        var node: BTreeNode!
		
		
        //若未指定插入节点，则寻找合适的插入位置
        if specificNode == nil {
            node = searchChild(rootNode: root, key: key)
        }
        //指定节点
        else {
            node = specificNode
        }
		
        
        //首先正常插入
		if node.keys.isEmpty {
			node.keys.append(key)
			node.datas.append(pos)
			node.pointers.append(newChildNode)
		}
		else {
			if key < node.keys.first! {
				node.keys.insert(key, atIndex: 0)
				node.datas.insert(pos, atIndex: 0)
				
				node.pointers.insert(newChildNode, atIndex: 0)
			}
			else if key > node.keys.last! {
				node.keys.insert(key, atIndex: node.keys.count)
				node.datas.insert(pos, atIndex: node.datas.count)
				
				node.pointers.append(newChildNode)
			}
			else {
				for index in 0 ..< node.keys.count - 1 {
					if key > node.keys[index] && key < node.keys[index + 1] {
						//判断父节点上升时，子节点插入的位置
						var insertIndex: Int {
							if newChildNode?.keys.first > node.pointers[index + 1]?.keys.last {
								return index + 2
							}
							else {
								return index + 1
							}
						}
						
						node.keys.insert(key, atIndex: index + 1)
						node.datas.insert(pos, atIndex: index + 1)
						
						node.pointers.insert(newChildNode, atIndex: insertIndex)
					}
				}
			}
		}
		
		
        //判断并进行分裂操作
        divide(presentNode: node)
    }
    
    
    //MARK: - 分裂操作
    private func divide(presentNode node: BTreeNode) {
        //若节点超载
        if node.keys.count > MAX_KEY_NUM {
			let start = MAX_KEY_NUM / 2 + 1
			
			
            //生成兄弟节点索引
            var brotherKeys = [IntMax]()
            for _ in start ..< node.keys.count {
                brotherKeys.append(node.keys[start])
                node.keys.removeAtIndex(start)      //从原节点删除
            }
			
			
			//生成兄弟节点position
			var brotherPos = Array<IntMax>()
			for _ in start ..< node.datas.count {
				brotherPos.append(node.datas[start])
				node.datas.removeAtIndex(start)
			}
			
			
            //生成兄弟节点指针
            var brotherPointers = [BTreeNode?]()
            for _ in start ..< node.pointers.count {
                brotherPointers.append(node.pointers[start])
                node.pointers.removeAtIndex(start)      //从原节点删除
            }
			
			
            //新建兄弟节点
            let brotherNode = BTreeNode(keys: brotherKeys, pointers: brotherPointers, father: nil, recordPosition: brotherPos)
			
			
			//将兄弟节点的子节点父指针指向兄弟节点
			for pointer in brotherNode.pointers {
				pointer?.father = brotherNode
			}
            
            
            //若当前节点无父节点，则新建
            if node.father == nil {
                let newRoot = BTreeNode(keys: [node.keys[MAX_KEY_NUM / 2]], pointers: [node, brotherNode], father: nil, recordPosition: [node.datas[MAX_KEY_NUM / 2]])
				
				//设置父节点
                node.father        = newRoot
                brotherNode.father = newRoot
				
				root = newRoot
				
				//从原节点删除
				node.keys.removeAtIndex(MAX_KEY_NUM / 2)
				node.datas.removeAtIndex(MAX_KEY_NUM / 2)
            }
            //若有，则添加至父节点
            else {
                //将中间索引值加入父节点
                addKey(node.keys[MAX_KEY_NUM / 2], position: node.datas[MAX_KEY_NUM / 2], specificNode: node.father, newChildNode: brotherNode)
				
				//设置兄弟节点的父节点
				brotherNode.father = node.father
				
                //从原节点删除
                node.keys.removeAtIndex(MAX_KEY_NUM / 2)
				node.datas.removeAtIndex(MAX_KEY_NUM / 2)
                
                
                //判断父节点是否需要分裂
                divide(presentNode: node.father!)
            }
        }
    }
    
    
    //MARK: - 寻找应当插入的节点
    private func searchChild(rootNode root: BTreeNode, key: IntMax) -> BTreeNode {
        var tree: BTreeNode!
        
        //无子节点
//		var has_pointer = false
//		for pointer in root.pointers {
//			if pointer != nil {
//				has_pointer = true
//			}
//		}
//		
//        if has_pointer == false {
//			return root
//        }
		if root.pointers.first! == nil {
			return root
		}
		
        
        //有子节点
		//中间插入
        for index in 0 ..< root.keys.count - 1 {
            if key > root.keys[index] && key < root.keys[index + 1] {
                tree = searchChild(rootNode: root.pointers[index + 1]!, key: key)
                return tree
            }
        }
		
		//尾部插入
		if key > root.keys.last {
			tree = searchChild(rootNode: root.pointers.last!!, key: key)
			return tree
		}
		
		//头部插入
        tree = searchChild(rootNode: root.pointers.first!!, key: key)
		
		
        return tree
    }
    
	
	//MARK: - 查询操作
	func search(presentRoot root: BTreeNode, key: IntMax) -> IntMax {
		//判断首尾
		if key > root.keys.last {
			return search(presentRoot: root.pointers.last!!, key: key)
		}
		else if key < root.keys.first {
			return search(presentRoot: root.pointers.first!!, key: key)
		}
		
		
		for index in 0 ..< root.keys.count - 1 {
			//判断中间
			if key > root.keys[index] && key < root.keys[index + 1] {
				return search(presentRoot: root.pointers[index + 1]!, key: key)
			}
			//判断是否相等
			else if key == root.keys[index] {
				return root.datas[index]
			}
		}
		
		//最后一个相等
		if key == root.keys.last {
			return root.datas.last!
		}
		
		return -1
	}
}