#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <windows.h>

#define MAX 10

int numOfResource, numOfProcesses;

int avai[MAX];
int state[MAX];
int state2[MAX];
int requests[MAX];
int max[MAX][MAX];
int need[MAX][MAX];
int allocated[MAX][MAX];

int bank_algorithm(int id)
{
	
	int i = 1, j = 1;
	bool isFound = false;
	bool isAllFinish = true;
	bool curFound = false;
	int work[MAX];
	bool finish[MAX];

	for (i = 1; i <= numOfResource; i++) {
		if (requests[i] > need[id][i] || requests[i] > avai[i]) {
			return 0;
		}
	}
	for (i = 1; i <= numOfResource; i++) {
		avai[i] = avai[i] - requests[i];
		allocated[id][i] = allocated[id][i] + requests[i];
		need[id][i] = need[id][i] - requests[i];
	}
	for (i = 1; i <= numOfResource; i++) {
		work[i] = avai[i];
	}
	for (i = 1; i <= numOfProcesses; i++) {
		finish[i] = false;
	}

	do{
		isFound = false;
		for (i = 1; i <= numOfProcesses&&!finish[i]; i++) {
			curFound = true;
			for (j = 1; j <= numOfResource; j++) {
				if (need[i][j] > work[j]) {
					curFound = false;
					break;
				}
			}
			if (curFound) {
				for (j = 1; j <= numOfResource; j++) {
					work[j] = work[j] + allocated[i][j];
				}
				finish[i] = true;
				isFound = true;
			}
		}	
	} while (isFound);
	
	for (i = 1; i <= numOfProcesses; i++) {
		if (!finish[i]) {
			isAllFinish = false;
		}
	}
	if (isAllFinish) {
		return 1;
	}else {
		for (i = 1; i <= numOfResource; i++) {
			avai[i] = avai[i] + requests[i];
			allocated[id][i] = allocated[id][i] - requests[i];
			need[id][i] = need[id][i] + requests[i];
		}
		return -1;
	}
}

int main()
{
	int i, j, p_num, ans;
	FILE *fp;

	printf("��ȷ�������ļ�input.txt���ڣ�����������output.txt\n");
	if ((fp = fopen("Input.txt", "r")) == NULL)
		printf("Read File Error\n");

	fscanf(fp, "%d", &numOfResource);
	for (i = 1; i <= numOfResource; i++)
		fscanf(fp, "%d", &avai[i]);

	fscanf(fp, "%d", &numOfProcesses);

	for (i = 1; i <= numOfProcesses; i++)
	{
		for (j = 1; j <= numOfResource; j++)
		{
			fscanf(fp, "%d", &max[i][j]);
			need[i][j] = max[i][j];
			allocated[i][j] = 0;
		}
	}
	//������ʼ���� 
	printf("Initial: \n");
	for (i = 1; i <= numOfResource; i++)
		printf("%c ", 'A' + i - 1);
	printf("\n");
	for (i = 1; i <= numOfResource; i++)
		printf("%d ", avai[i]);
	printf("\n");

	while (fscanf(fp, "%d", &p_num) != EOF)
	{
		for (i = 1; i <= numOfResource; i++)
			fscanf(fp, "%d", &requests[i]);
		printf("Process %d requests (", p_num);
		for (i = 1; i <= numOfResource; i++)
		{
			printf("%d", requests[i]);
			if (i != numOfResource) printf(",");
		}
		printf(")");

		ans = bank_algorithm(p_num);
		if (ans == 1)                                               //��������
		{
			printf(" �C granted\n");
		}
		else if (ans == 0)                                          //���������� ������������
		{
			printf("�C refused (extend the amount of available)\n");
		}
		else
		{
			printf(" �C refused (Deadlock is possible)\n");
		}

		for (i = 1; i <= numOfResource; i++)
		{
			if (need[p_num][i] != 0)
				break;
		}
		if (i == numOfResource + 1)
		{
			printf("Process %d finishes\n", p_num);
			for (i = 1; i <= numOfResource; i++)
				avai[i] = avai[i] + max[p_num][i];
		}

	}

	system("pause");
}
