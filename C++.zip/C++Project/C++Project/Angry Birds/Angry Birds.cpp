//
//  Angry Birds.cpp
//  C++ project
//
//  Created by zhy on 14/10/27.
//  Copyright (c) 2014年 zhy. All rights reserved.
//

#include "Angry Birds.h"

using namespace std;

int main()
{
    char ch;
    int i = 0;
    
loop:
    cout << "Shoot a bird or not (y/n): ";
    cin >> ch;
    
    while (i <= 20) {
        if (ch == 'y') {
            i ++;
            goto loop;
        }
        if (ch == 'n') {
            cout << endl
            << "All " << i << " birds" << endl;
            
            exit(0);
        }
    }
    
    cout << endl
    << "You can't shoot anymore." << endl
    << "All 20 birds." << endl;
    getchar();
    
    return 0;
}