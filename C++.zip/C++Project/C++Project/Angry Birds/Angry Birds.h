//
//  Angry Birds.h
//  C++ project
//
//  Created by zhy on 14/10/27.
//  Copyright (c) 2014年 zhy. All rights reserved.
//

#ifndef __C___project__Angry_Birds__
#define __C___project__Angry_Birds__

#include <stdio.h>
#include <iostream>

#endif /* defined(__C___project__Angry_Birds__) */

void shoot();