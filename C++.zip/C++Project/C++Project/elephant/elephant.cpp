//
//  elephant.cpp
//  C++ project
//
//  Created by zhy on 14/11/3.
//  Copyright (c) 2014年 zhy. All rights reserved.
//

#include <stdio.h>

