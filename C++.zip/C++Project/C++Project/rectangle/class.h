//
//  class.h
//  C++ project
//
//  Created by zhy on 14/9/29.
//  Copyright (c) 2014年 zhy. All rights reserved.
//

#ifndef C___project_class_h
#define C___project_class_h


#endif

class rec {
    
private:
    double x, y;
    
public:
    double getX();
    double getY();
    void setX(double);
    void setY(double);
};

class Cal {
    
private:
    rec a,b,c;
    
public:
    double calculate(rec, rec, rec);
};