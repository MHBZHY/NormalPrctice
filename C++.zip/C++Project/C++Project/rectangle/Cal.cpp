//
//  Cal.cpp
//  C++ project
//
//  Created by zhy on 14/9/29.
//  Copyright (c) 2014年 zhy. All rights reserved.
//

#include <stdio.h>
#include "class.h"
#include <cmath>

double Cal::calculate(rec a, rec b, rec c) {
    double width, length;
    
    width = sqrt(pow(a.getX() - b.getX(), 2.0) + pow(a.getY() - b.getY(), 2.0));
    length = sqrt(pow(b.getX() - c.getX(), 2.0) + pow(b.getY() - c.getY(), 2.0));
    
    return width * length;
}