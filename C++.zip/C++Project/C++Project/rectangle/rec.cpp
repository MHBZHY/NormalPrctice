//
//  rec.cpp
//  C++ project
//
//  Created by zhy on 14/9/29.
//  Copyright (c) 2014年 zhy. All rights reserved.
//

#include <stdio.h>
#include "class.h"

double rec::getX() {
    return x;
}

double rec::getY() {
    return y;
}

void rec::setX(double x) {
    rec::x = x;
}

void rec::setY(double y) {
    rec::y = y;
}