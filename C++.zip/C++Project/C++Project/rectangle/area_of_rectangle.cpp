//
//  area_of_rectangle.cpp
//  C++ project
//
//  Created by zhy on 14/9/29.
//  Copyright (c) 2014年 zhy. All rights reserved.
//

#include <stdio.h>
#include <iostream>
#include "class.h"
using namespace std;

int main() {
    
    rec a, b, c;
    Cal calculate;
    double x, y, area;
    
    cout << "Please input the first coordinate: ";
    cin >> x >> y;
    
    a.setX(x);
    a.setY(y);
    
    cout << "Please input the second coordinate: ";
    cin >> x >> y;
    
    b.setX(x);
    b.setY(y);
    
    cout << "Please input the third coordinate: ";
    cin >> x >> y;
    
    c.setX(x);
    c.setY(y);
    
    area = calculate.calculate(a, b, c);
    
    cout << "The area you want is: " << area << endl;
    
    return 0;
}