//
//  area of circle.cpp
//  C++ project
//
//  Created by zhy on 14/9/29.
//  Copyright (c) 2014年 zhy. All rights reserved.
//

#include <stdio.h>
#include <iostream>
#include <cmath>
using namespace std;

int main() {
    
    const double pi = 3.1416;
    double radius, area;
    
    cout << "Please input the circle's radius: ";
    cin >> radius;
    
    area = pi * pow(radius, 2.0);
    
    cout << "The area you want is: " << area << endl;
    
    return 0;
}