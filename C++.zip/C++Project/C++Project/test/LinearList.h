#include<string>
#include<sstream>
#include<iostream>
using namespace std;
#pragma once

template <class T>
class LinearList
{
private:
	int length;
	int MaxSize;
	int *elements;

public:
	LinearList(int MaxListSize = 10);
	~LinearList() { delete[] elements; };
	bool find(int index, int value);
	LinearList<T>& insert(int index, int value);
	string to_string();
	int get_length() const { return length; };
	int* getElements() { return elements; };
};

