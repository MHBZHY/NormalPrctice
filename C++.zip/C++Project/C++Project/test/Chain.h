#include<string>
#include<sstream>
#include<iostream>
#include<stdlib.h>
#include "LinearList.h"
using namespace std;

template <class T>
class ChainNode;

#pragma once
template<class T>
class Chain
{
public:
	Chain() { first = 0; }
	~Chain();
	Chain<T>& Insert(int k, const T& x);
	Chain<T>& convert(LinearList<T> *head);
private:
	ChainNode<T>* first;
};

template <class T>
class ChainNode
{
	friend Chain<T>;
private:
	T data;
	ChainNode<T>* link;
};



