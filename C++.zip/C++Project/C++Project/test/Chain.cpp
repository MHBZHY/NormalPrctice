#include "Chain.h"
#include"LinearList.h"
#include<stdlib.h>

template< class T>
Chain<T>::~Chain() {

	ChainNode<T> *next;
	while (first) {

		next = first->link;
		delete first;
		first = next;
	}
}

template<class T>
Chain<T>& Chain<T>::Insert(int k, const T& x)
{
	ChainNode<T> *corren = new ChainNode<T>;
	corren->data = x;
	ChainNode<T> *p = first;
	int z = 1;
	if (k == 0)
	{
		corren->link = first;
		first->link = corren;
	}
	while (!p || z != k)
	{
		p = p->link;
		z++;
	}
	if (!p || !p->link)
	{
		corren->link = p->link;
		p->link = corren;
	}
	return *this;
}

template<class T>
LinearList<T>::LinearList(int MaxListSize)
{
	MaxSize = MaxListSize;
	elements = new int[MaxSize];
	length = 0;
}

template <class T>
bool LinearList<T>::find(int index, int value)
{
	if (index < 0 || index > length) return false;

	return elements[index] == value;
}

template<class T>
LinearList<T> & LinearList<T>::insert(int index, int value)
{
	if (index < 0 || index > length) return *this;
	if (length == MaxSize) return *this;

	for (int i = length - 1; i >= index; i--)
	{
		elements[i + 1] = elements[i];
	}

	elements[index] = value;
	length++;

	return *this;
}

template <class T>
string LinearList<T>::to_string()
{
	string resultString = "";

	for (int i = 0; i < length; i++)
	{
		stringstream ss;
		string str;
		ss << elements[i];
		ss >> str;
		resultString = resultString + str + "   ";
	}

	return resultString;
}

template <class T>
Chain<T>& Chain<T>::convert(LinearList<T> *head)
{
	ChainNode<T> *curren = first;
	
	for (int i = 0; i < head->get_length(); i++)
	{
		curren->data = head->getElements()[i];
		curren = curren->link;
	}
	
	ChainNode<T> *q = first;
	
	while (q)
	{
		cout << curren->data << "";
		curren = curren->link;
	}
}

int main()
{
	LinearList<int> *list = new LinearList<int>(11);

	list->insert(0, 10);
	list->insert(0, 9);
	list->insert(0, 8);
	list->insert(0, 7);
	list->insert(0, 6);
	list->insert(0, 5);
	list->insert(0, 4);
	list->insert(0, 3);
	list->insert(0, 2);
	list->insert(0, 1);
	
	cout << "length=  " << list->get_length() << endl;
	cout << "now we have inserted some date in it" << endl;
	
	list->find(3, 4);
	
	cout << "show all of the data" << endl;
	cout << list->to_string() << endl;
	cout << "start to convert:" << endl;
	
	Chain<int> *p = new Chain<int>();
	p->convert(list);
	
	cout << "convered success;" << endl;
	system("pause");	
}