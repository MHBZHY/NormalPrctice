//
//  Triangle.cpp
//  C++ project
//
//  Created by zhy on 14/10/20.
//  Copyright (c) 2014年 zhy. All rights reserved.
//

#include <stdio.h>
#include <math.h>
#include <iostream>
#include "triangle.h"

using namespace std;

int main() {
    double area, a, b, c;
    triangle tri;
    
    cout << "Please input the three sides of a triangle: " << endl;
    cin >> a >> b >> c;
    
    tri.setSides(a, b, c);
    area = tri.calculate();
    
    cout << "The area is: " << area << endl;
    
    return 0;
}