//
//  triangle.h
//  C++ project
//
//  Created by zhy on 14/10/20.
//  Copyright (c) 2014年 zhy. All rights reserved.
//

#ifndef C___project_triangle_h
#define C___project_triangle_h

#define s (a + b + c)/2

#endif

class triangle {
private:
    double a, b, c;
    
public:
    void setSides(double, double, double);
    double calculate();
};