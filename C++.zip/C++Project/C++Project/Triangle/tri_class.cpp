//
//  tri_class.cpp
//  C++ project
//
//  Created by zhy on 14/10/20.
//  Copyright (c) 2014年 zhy. All rights reserved.
//

#include <stdio.h>
#include <math.h>
#include "triangle.h"

void triangle::setSides(double a, double b, double c) {
    triangle::a = a;
    triangle::b = b;
    triangle::c = c;
}

double triangle::calculate() {
    double area;
    
    area = sqrt(s * (s - a) * (s - b) * (s - c));
    
    return area;
}
