//
//  main.cpp
//  C++Project
//
//  Created by zhy on 15/12/1.
//  Copyright © 2015年 zhy. All rights reserved.
//



#include"main.hpp"

int add_words(Root root)
{
    int len = 0;
    char twords[20] = {0};
    WORD_NODE *this;
    printf("plase input the word:\n");
    gets(twords);
    if(twords[19] != '\0' && twords[19] != 0){
        printf("Input error");
        return FALSE;
    }
    if(find_words(root, twords)){
        printf("the word is already exist");
        return FALSE;
    }
    len = strlen(twords);
    
    for(int i = 0; i < len; i++){
        if(root == NULL){
            root = creat_next();
            /*	root = (WORD_NODE*)malloc(sizeof(WORD_NODE));*/
            root -> chr = (int)twords[i];
            /*	root -> this_level = NULL;
             root -> next_level = NULL;*/
            this = root;
            continue;
        }
        while(this -> chr != twords[i]){
            if(this -> this_level != NULL){
                this = this -> this_level;
                continue;
            }
            this = this -> this_level = creat_next();
            this -> chr = twords[i];
        }
        if(i < len - 1){
            if(this -> next_level != NULL){
                this = this -> next_level;
                continue;
            }
            this = this -> next_level = creat_next();
            this -> chr = twords[i + 1];
        }
    }
}

int del_words(Root root, char *words)
{
    if(!find_words(root, words)){
        printf("not have such word");
        return FALSE;
    }
    WORD_NODE *this;
    this = root;
    int len = strlen(words);
    WORD_NODE **p;
    p = malloc(sizeof(WORD_NODE) * (len - 1));
    for(int i = 0, j = 1; i < len; i++){
        /*if(i < len - 1){
         if(this -> next_level -> this_level== NULL){
         free(this);
         *	j = 0;*
         return TRUE;
         }
         }*/
        while(this -> chr != words[i]){
            this = this -> this_level;
            continue;
        }
        if(i < len - 1){
            p[i] = this;
            this = this -> next_level;
            continue;
        }
        if(this -> next_level != NULL){
            i--;
            this = this -> this_level;
        }
    }
    free(this);
    for(int i = len - 1; i > 0; i--){
        if(p[i] -> this_level != NULL)
            return TRUE;
        else free(p[i]);
    }
    
    
}
int set_words(char *words);

int find_words(Root root, char *words)
{
    int len = strlen(words);
    WORD_NODE *this = root;
    for(int i = 0; i < len; i++){
        while(words[i] != this -> chr){
            if(this -> this_level == NULL)
                return FALSE;
            this = this -> this_level;
            
        }
        if(this -> next_level != NULL && i != len - 1){
            this = this -> next_level;
        }
        if(this -> next_level == NULL && i != len - 1)
            return FALSE;
    }
    return TRUE;
}

WORD_NODE *creat()
{
    WORD_NODE *root;
    root = malloc(sizeof(WORD_NODE));
    return root;
}

WORD_NODE *creat_next()
{
    WORD_NODE *next;
    next = malloc(sizeof(WORD_NODE));
    next -> this_level = NULL;
    next -> next_level = NULL;
    return next;
}