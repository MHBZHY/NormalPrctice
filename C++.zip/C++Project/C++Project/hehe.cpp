//
//  hehe.cpp
//  C++Project
//
//  Created by zhy on 16/2/1.
//  Copyright © 2016年 zhy. All rights reserved.
//

#include "main.hpp"

int x = 10;