//
//  main.cpp
//  DataStructrue Practice
//
//  Created by zhy on 15/10/21.
//  Copyright © 2015年 zhy. All rights reserved.
//

#include "HuffmanCompress.hpp"

int main() {
	
	HuffmanTree tree;
	
//    tree.compress_and_output("/Users/zhy/Desktop/COVER.bmp", "/Users/zhy/Desktop/COVER.bmp.bin");
//    tree.decompress_and_output("/Users/zhy/Desktop/COVER.bmp.bin", "/Users/zhy/Desktop/COVER.bmp.out");
//    tree.compress_and_output("/Users/zhy/Desktop/Untitled-1.txt", "/Users/zhy/Desktop/Untitled-1.txt.bin");
//    tree.decompress_and_output("/Users/zhy/Desktop/Untitled-1.txt.bin", "/Users/zhy/Desktop/Untitled-1.txt.out");
//    tree.compress_and_output("/Users/zhy/Desktop/IMG_0001.bmp", "/Users/zhy/Desktop/IMG_0001.bmp.bin");
//    tree.decompress_and_output("/Users/zhy/Desktop/IMG_0001.bmp.bin", "/Users/zhy/Desktop/IMG_0001.bmp.out");
    
	return 0;
}
