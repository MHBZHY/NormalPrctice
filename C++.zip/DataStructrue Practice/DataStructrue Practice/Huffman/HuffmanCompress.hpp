//
//  HuffmanCompress.hpp
//  DataStructrue Practice
//
//  Created by zhy on 15/10/21.
//  Copyright © 2015年 zhy. All rights reserved.
//

#ifndef HuffmanCompress_hpp
#define HuffmanCompress_hpp

#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <stack>
#include <map>
using namespace std;

static const unsigned char mask[8] =
{
	0x80, /* 10000000 */
	0x40, /* 01000000 */
	0x20, /* 00100000 */
	0x10, /* 00010000 */
	0x08, /* 00001000 */
	0x04, /* 00000100 */
	0x02, /* 00000010 */
	0x01  /* 00000001 */
};

static const unsigned char push[2] =
{
	0x00	,	/* 00000000 */
	0x01		/* 00000001 */
};

typedef struct HuffmanTreeNode {
	struct HuffmanTreeNode *lChild = nullptr, *rChild = nullptr, *parent = nullptr;
	int frequency = 0;
	char value;
	string code = "";
}HaffmanTreeNode;

//typedef struct HuffmanTreeStruct {
//	vector<HuffmanTreeNode> vector_huffmannode;
//	int effective_bytes;
//	
//	HuffmanTreeStruct() {
//		for (int i = 0; i < 256; i++) {
//			vector_huffmannode.push_back(*new HuffmanTreeNode());
//		}
//	}
//}HuffmanTreeStruct;

class HuffmanTree {
private:
	int effective_bytes;
	vector<HuffmanTreeNode> vector_huffmannode;
	map<char, string> map_encode;
	HuffmanTreeNode *root = nullptr;
	
	void create_tree();
	void encode();
	void decode();
	unsigned char str_to_bin(string str);
	string bin_to_str(unsigned char c);
	
public:
	bool compress_and_output(string in_file_path, string out_file_path);
	bool decompress_and_output(string in_file_path, string out_file_path);
};

#endif /* HuffmanCompress_hpp */
