//
//  HuffmanCompress.cpp
//  DataStructrue Practice
//
//  Created by zhy on 15/10/21.
//  Copyright © 2015年 zhy. All rights reserved.
//

#include "HuffmanCompress.hpp"

bool HuffmanTree::compress_and_output(string in_file_path, string out_file_path) {
	ifstream in(in_file_path, ios::binary);
	ofstream out(out_file_path, ios::binary);
	
    /*
     *	count frequency
     */
    
    if (this->vector_huffmannode.empty()) {
        this->vector_huffmannode = *new vector<HuffmanTreeNode>(256);
    }
    
    while (in.peek() != EOF) {
        char c;
        
        in.read(&c, 1);
        if (this->vector_huffmannode[(int)c + 128].frequency == 0) {
            this->vector_huffmannode[(int)c + 128].value = c;
        }
        this->vector_huffmannode[(int)c + 128].frequency++;
    }
    
    in.close();
    in.open(in_file_path);
    
    /*
     *	count effective bytes
     */
    
    int effective_bytes = 0;
    
    for (int i = 0; i < 256; i++) {
        if (this->vector_huffmannode[i].frequency != 0) {
            effective_bytes++;
        }
    }
    
    this->effective_bytes = effective_bytes;	//store into class variable
	
	/*
	 *	create huffuman tree
	 */
	
	this->create_tree();
	
	/*
	 *	encode original data
	 */
	
	this->encode();
	
	/*
	 *	write the coding data to compressed file
	 */
	
	if (!out) {
		cout << "Can not write file to the given destination." << endl;
		return false;
	}
	
	out.write((char*)&this->effective_bytes, sizeof(int));
	
	/*
	 *	write file head
	 */
	
//	for (int i = 0; i < 256; i++) {
//		if (this->vector_huffmannode[i].frequency != 0) {
//			out.write((char*)&this->vector_huffmannode[i].frequency, sizeof(int));
//			out.write(&this->vector_huffmannode[i].value, 1);
//		}
//		
//		if (i == effective_bytes - 1) {
//			char c = '\n';
//			out.write(&c, 1);
//		}
//	}
	
	for (vector<HuffmanTreeNode>::iterator it = this->vector_huffmannode.begin(); it != this->vector_huffmannode.end(); ++it) {
		if (it->frequency > 0 && it->lChild == nullptr) {
			out.write(&it->value, 1);
			out.write((char*)&it->frequency, sizeof(int));
		}
	}
    
	/*
	 *	compress main file
	 */
	
	string temp = "";
	
	while (in.peek() != EOF) {
        char c;
		in.read(&c, 1);
        
        if (in.peek() == EOF) {
            printf("file end.");
        }
		
		temp += this->map_encode[c];
		while (temp.length() >= 8) {
			c = str_to_bin(temp.substr(0, 8));
			out.write(&c, 1);
			temp.erase(0, 8);
		}
	}
    
    if (temp.length() > 0) {
        char c;
        
        temp.append(8 - temp.length(), '0');
        c = str_to_bin(temp.substr(0, 8));
        out.write(&c, 1);
        temp.erase(0, 8);
    }
	
	/*
	 *	end
	 */
	
	//close file stream
	in.close();
	out.close();
	
	//clear vector
	this->vector_huffmannode.clear();
	
	return true;
}

bool HuffmanTree::decompress_and_output(string in_file_path, string out_file_path) {
	ifstream in(in_file_path, ios::binary);
	ofstream out(out_file_path, ios::binary);
	string temp = "";
    
    /*
     *	get count data
     */
    
    //read effective bytes
    in.read((char*)&this->effective_bytes, sizeof(int));
    
    //read freq data
    for (int i = 0; i < this->effective_bytes; i++) {
        char c;
        int t;
        
        in.read(&c, 1);
        in.read((char*)&t, sizeof(int));
        
        this->vector_huffmannode.push_back(*new HuffmanTreeNode());
        this->vector_huffmannode.back().value = c;
        this->vector_huffmannode.back().frequency = t;
    }
	
	/*
	 *	create hufuman tree
	 */
	
	this->create_tree();
	
	/*
	 *	scan compressed file and
	 *	write translated code into file
	 */
    
    HuffmanTreeNode *p = root;
    int count = 0;
	while (in.peek() != EOF) {
		char c;
		in.read(&c, 1);
        
        if (in.peek() == EOF) {
            printf("File end.\n");
        }
		
		temp += this->bin_to_str((unsigned char)c);
        while (temp.length() > 0 || p->lChild == nullptr) {
            if (p->lChild != nullptr) {
                if (temp[0] == '0') {
                    p = p->lChild;
                }
                else {
                    p = p->rChild;
                }
                
                temp.erase(0, 1);
            }
            else if (p->frequency > 0) {
                c = p->value;
                count++;
                if (count == 269700) {
                    cout;
                }
                out.write(&c, 1);
                p->frequency--;
                
                p = root;
            }
            else {
                break;
            }
        }
	}
    
	in.close();
    out.close();
	
    //clear
	this->vector_huffmannode.clear();
	
	return true;
}

void HuffmanTree::create_tree() {
	for (int i = 0; i < this->effective_bytes - 1; i++) {
		int min = -1, second_min = -1;
		int freq_max = 0;
		
		for (int i = 0; i < this->vector_huffmannode.size(); i++) {
			if (this->vector_huffmannode[i].frequency > freq_max) {
				freq_max = this->vector_huffmannode[i].frequency;
			}
		}
		
		int weight = freq_max;
		
		for (int i = 0; i < this->vector_huffmannode.size(); i++) {
			if (this->vector_huffmannode[i].frequency <= weight && this->vector_huffmannode[i].frequency > 0 && this->vector_huffmannode[i].parent == nullptr) {
				weight = this->vector_huffmannode[i].frequency;
				min = i;
			}
		}
		
		//left child
		if (min != -1) {
			this->vector_huffmannode.push_back(*new HuffmanTreeNode());
			this->vector_huffmannode.back().frequency = this->vector_huffmannode[min].frequency;
			this->vector_huffmannode.back().lChild = &this->vector_huffmannode[min];
			this->vector_huffmannode[min].parent = &this->vector_huffmannode.back();
		}
		
		weight = freq_max;
		
		for (int i = 0; i < this->vector_huffmannode.size(); i++) {
			if (this->vector_huffmannode[i].frequency <= weight && this->vector_huffmannode[i].frequency > 0 && this->vector_huffmannode[i].parent == nullptr && i != this->vector_huffmannode.size() - 1) {
				weight = this->vector_huffmannode[i].frequency;
				second_min = i;
			}
		}
		
		//right child
		if (second_min != -1) {
			this->vector_huffmannode.back().frequency += this->vector_huffmannode[second_min].frequency;
			this->vector_huffmannode.back().rChild = &this->vector_huffmannode[second_min];
			this->vector_huffmannode[second_min].parent = &this->vector_huffmannode.back();
		}
	}
	
	//return root
	this->root = &this->vector_huffmannode.back();
}

void HuffmanTree::encode() {
	stack<HuffmanTreeNode*> s;
	HuffmanTreeNode *p = this->root;
	int flag = 0;		//0: left, 1: right
	
	/*
	 *	iterate
	 */
	
	while(p != nullptr || !s.empty()) {
		while (p != nullptr) {
			if (p != nullptr && p->parent != nullptr) {
				if (flag == 0) {
					p->code += p->parent->code + "0";
				}
				else if (flag == 1) {
					p->code += p->parent->code + "1";
				}
			}
			
			if (p->lChild == nullptr) {
				this->map_encode.insert(pair<char, string>(p->value, p->code));		//insert value : code pair
                cout << "freq: " << p->frequency << "   " << "code: " << p->code << "   " << p->value << endl;
			}
			
			s.push(p);
			p = p->lChild;
			
			flag = 0;
		}
		
		if (!s.empty()) {
			p = s.top();
			s.pop();
			p = p->rChild;
			
			flag = 1;
		}
	}
}

unsigned char HuffmanTree::str_to_bin(string str) {
	int a = atoi(str.c_str());
	int b = 1;
	int ans = 0;
	
	while(a != 0)
	{
		ans += a%10 * b;
		b *= 2;
		a /= 10;
	}
	
	return (unsigned char)ans;
}

string HuffmanTree::bin_to_str(unsigned char c) {
	string ans;
	while(c != 0)
	{
		ans.insert(ans.begin(), (unsigned char)(c%2 + '0'));
		c /= 2;
	}
	
	if(ans.length() < 8)
	{
		ans.insert(ans.begin(), 8-ans.length(), '0');
	}
	return ans;
}
