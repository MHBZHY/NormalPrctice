//
//  Graph.hpp
//  DataStructrue Practice
//
//  Created by zhy on 15/11/11.
//  Copyright © 2015年 zhy. All rights reserved.
//

#ifndef Graph_hpp
#define Graph_hpp

#include <iostream>
#include <fstream>
#include <string>
#include <array>
#include <vector>
#include <deque>
#include <map>
using namespace std;

struct node;

typedef struct path {
    node *next;
    int weight;
    
    bool flag = false;
    
    path(struct node *next, int weight) {
        this->next = next;
        this->weight = weight;
    }
}edge;

typedef struct node {
    int code;
    int price;
    string name;
    vector<edge> edge;
    
    vector<path>::iterator present_it;
    
    bool flag = false;
    
    node(int code, string name, int price) {
        this->code = code;
        this->name = name;
        this->price = price;
    }
}Graph_node;

class ScenicGraph {
    vector<Graph_node> _scenic_spot_list;
//    map<int, int> _scenic_spot_inform;
    
    void reset_flag();
    bool if_edge_true(int spot_num);
    bool if_nextnode_true(Graph_node *p);
    bool if_all_nextnode_true(vector<Graph_node*> p_list);
    
public:
    ScenicGraph(string vertex_edge, string edge_edge);
    
    void create_scenic_spot_graph();
    bool query_spot_information();
    bool navigate_tourism_spot();
    bool search_shortest_path();
    void lay_circuit_planning();
};

#endif /* Graph_hpp */
