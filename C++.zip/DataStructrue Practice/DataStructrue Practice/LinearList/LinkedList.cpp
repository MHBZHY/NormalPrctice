//
//  LinkedList.cpp
//  C++ project
//
//  Created by zhy on 15/9/25.
//  Copyright © 2015年 zhy. All rights reserved.
//

#include "LinkedList.hpp"

template<class T>
LinkedList<T>::~LinkedList()
{
    Node<T> *p = head;
    
    while (p != nullptr)
    {
        head = p->next;
        delete p;
        p = head;
    }
}

template <class T>
bool LinkedList<T>::find(int index, T &value)
{
    Node<T> *p = head;
    
    while (p != nullptr)
    {
        if (p->index == index)
        {
            value = p->value;
            return true;
        }
        
        p = p->next;
    }
    
    return false;
}

template<class T>
int LinkedList<T>::search(T &value)
{
    Node<T> *p = head;
    
    while (p != nullptr)
    {
        if (p->value == *value)
        {
            return p->index;
        }
        
        p = p->next;
    }
    
    return 0;
}

template<class T>
LinkedList<T>& LinkedList<T>::Delete(int index, T &value)
{
    // TODO: 在此处插入 return 语句
    Node<T> *p = head;
    
    if (index <= 0 || index > length)
    {
        return *this;
    }
    else
    {
        while (p != nullptr)
        {
            if (p->index == index)
            {
                if (p->next->next != nullptr)
                {
                    p->next = p->next->next;
                }
                
                p->value = value;
                delete p;
                
                break;
            }
            
            p = p->next;
        }
    }
}

template <class T>
LinkedList<T>& LinkedList<T>::insert(int index, const T &value)
{
    Node<T> *p = head;
    
    if (index <= 0)
    {
        return *this;
    }
    else if (index > length)
    {
        while (p != nullptr)
        {
            p = p->next;
        }
        
        p = new Node<T>;
        p->index = index;
        p->value = value;
        p->next = nullptr;
        
        length++;
    }
    else
    {
        while (p != nullptr)
        {
            if (p->index == index)
            {
                Node<T> *q = new Node<T>;
                q->next = p;
                p = q;
                
                length++;
                break;
            }
            
            p = p->next;
        }
    }
}

template <class T>
void LinkedList<T>::toString() {
    while (head != nullptr) {
        cout << head->value;
        head = head->next;
    }
}