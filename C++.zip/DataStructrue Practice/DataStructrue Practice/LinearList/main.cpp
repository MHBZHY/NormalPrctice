//
//  main.cpp
//  C++ project
//
//  Created by zhy on 15/9/25.
//  Copyright © 2015年 zhy. All rights reserved.
//

#include <stdio.h>

int main() {
    
    
    
    return 0;
}