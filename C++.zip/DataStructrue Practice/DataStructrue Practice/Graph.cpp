//
//  Graph.cpp
//  DataStructrue Practice
//
//  Created by zhy on 15/11/11.
//  Copyright © 2015年 zhy. All rights reserved.
//

#include "Graph.hpp"

ScenicGraph::ScenicGraph(string vertex_edge, string edge_edge) {
    ifstream in(vertex_edge);
    int scenic_num;
    
    in >> scenic_num;
    
    while (!in.eof()) {
        int code, price;
        string name;
        
        in >> code >> name >> price;
        
        _scenic_spot_list.push_back(*new Graph_node(code, name, price));
    }
    
    in.close();
    in.open(edge_edge);
    
    while (!in.eof()) {
        int spot_code, next_spot_code, weight;
        
        in >> spot_code >> next_spot_code >> weight;
        
        _scenic_spot_list[spot_code].edge.push_back(*new edge(&_scenic_spot_list[next_spot_code], weight));
        _scenic_spot_list[spot_code].present_it = _scenic_spot_list[spot_code].edge.begin();
        _scenic_spot_list[next_spot_code].edge.push_back(*new edge(&_scenic_spot_list[spot_code], weight));
        _scenic_spot_list[next_spot_code].present_it = _scenic_spot_list[next_spot_code].edge.begin();
    }
}

void ScenicGraph::create_scenic_spot_graph() {
    cout
    << "===== Create Scenic Spot Graph =====" << endl
    << "Vertex number: " << _scenic_spot_list.size() << endl
    << "----- Vertex -----" << endl;
    
    for (vector<Graph_node>::iterator it = _scenic_spot_list.begin(); it != _scenic_spot_list.end(); it++) {
        cout << it->code << "-" << it->name << endl;
    }
    
    cout << "----- Edge -----" << endl;
    
    //iterat vertexs
    for (vector<Graph_node>::iterator it_node = _scenic_spot_list.begin(); it_node != _scenic_spot_list.end(); it_node++) {
        //iterat the vertex's edges
        for (vector<edge>::iterator it_first_edge = it_node->edge.begin(); it_first_edge != it_node->edge.end(); it_first_edge++) {
            if (it_first_edge->flag == false) {
                cout << "(v" << it_node->code << ", v" << it_first_edge->next->code << ") " << it_first_edge->weight << endl;
                it_first_edge->flag = true;
                
                //iterat the second node's edge, judge if the edge's next node is equal to the first node
                for (vector<edge>::iterator it_second_edge = it_first_edge->next->edge.begin(); it_second_edge != it_first_edge->next->edge.end(); it_second_edge++) {
                    if (it_second_edge->next == &*it_node) {
                        it_second_edge->flag = true;
                    }
                }
            }
        }
    }
    
    //reset flag
    this->reset_flag();
}

bool ScenicGraph::query_spot_information() {
    cout << "===== Query Spot Information =====" << endl;
    
    for (vector<Graph_node>::iterator it = _scenic_spot_list.begin(); it != _scenic_spot_list.end(); it++) {
        cout << it->code << "-" << it->name << endl;
    }
    
    cout << "Please input the spot number you want to query: ";
    
    int spot_num;
    cin >> spot_num;
    
    if (spot_num > 6 || spot_num < 0) {
        return false;
    }
    
    cout
    << _scenic_spot_list[spot_num].name << endl
    << "Tickets$" << _scenic_spot_list[spot_num].price << endl;
    
    return true;
}

bool ScenicGraph::navigate_tourism_spot() {
    cout << "===== navigate Tourism Spot =====" << endl;
    
    for (vector<Graph_node>::iterator it = _scenic_spot_list.begin(); it != _scenic_spot_list.end(); it++) {
        cout << it->code << "-" << it->name << endl;
    }
    
    cout << "Please input the origin spot number: ";
    
    int spot_num;
    cin >> spot_num;
    
    if (spot_num > 6 || spot_num < 0) {
        return false;
    }
    
    Graph_node *p = &_scenic_spot_list[spot_num];
    deque<Graph_node*> s_node;
    
    p->flag = true;
    
    while (1) {
        while (!if_nextnode_true(p) && p->present_it != p->edge.end()) {
            for (vector<edge>::iterator it = p->present_it; it != p->edge.end(); it++) {
                p->present_it = it + 1;
                
                if (it->next->flag == false) {
                    s_node.push_front(p);
                    p = it->next;
                    p->flag = true;
                    
                    break;
                }
            }
        }
        
        if (s_node.size() == _scenic_spot_list.size() - 1) {
            //if all node's flag are true, excute this
            for (int i = s_node.size() - 1; i >= 0; --i) {
                cout << "Path" << s_node.size() - i << ": " + s_node[i]->name + " -> ";
            }
            
            cout << p->name << endl;
        }
        
        p->flag = false;
        p->present_it = p->edge.begin();
        p = s_node.front();
        s_node.pop_front();
        
        if (s_node.empty() && p->present_it == p->edge.end()) {
            break;
        }
    }
    
    return true;
}

bool ScenicGraph::search_shortest_path() {
    cout << "===== Search Shortest Path =====" << endl;
    
    for (vector<Graph_node>::iterator it = _scenic_spot_list.begin(); it != _scenic_spot_list.end(); it++) {
        cout << it->code << "-" << it->name << endl;
    }
    
    cout << "Please input the number of origin: ";
    
    int spot_ori_num;
    cin >> spot_ori_num;
    
    if (spot_ori_num < 0 || spot_ori_num > 6) {
        return false;
    }
    
    cout << "Please input the number of destination: ";
    
    int spot_des_num;
    cin >> spot_des_num;
    
    if (spot_des_num < 0 || spot_des_num > 6) {
        return false;
    }
    
    Graph_node *p = &_scenic_spot_list[spot_ori_num];
    deque<Graph_node*> s_node;
    deque<edge*> s_edge;
    string spot_str;
    int weight = 0;
    
    p->flag = true;
    
    while (1) {
        while (!if_nextnode_true(p) && p->present_it != p->edge.end()) {
            for (vector<edge>::iterator it = p->present_it; it != p->edge.end(); it++) {
                p->present_it = it + 1;
                
                if (it->next->flag == false) {
                    s_node.push_front(p);
                    s_edge.push_front(&*it);
                    p = it->next;
                    p->flag = true;
                    
                    break;
                }
            }
            
            if (p == &_scenic_spot_list[spot_des_num]) {
                int temp_weight = 0;
                
                for (int i = s_edge.size() - 1; i >= 0; i--) {
                    temp_weight += s_edge[i]->weight;
                }
                
                if (weight == 0 || temp_weight < weight) {
                    weight = temp_weight;
                    spot_str.clear();
                    
                    for (int i = s_node.size() - 1; i >= 0; i--) {
                        spot_str.insert(spot_str.size(), s_node[i]->name);
                    }
                    spot_str.insert(spot_str.size(), p->name);
                }
                
                break;
            }
        }
        
        p->flag = false;
        p->present_it = p->edge.begin();
        p = s_node.front();
        s_node.pop_front();
        
        if (!s_edge.empty()) {
            s_edge.pop_front();
        }
        
        if (s_node.empty() && p->present_it != p->edge.end()) {
            cout << "The shortest path: ";
            
            while (spot_str.size() > 0) {
                cout << spot_str.substr(0, 5);
                spot_str.erase(0, 5);
                
                if (spot_str.size() != 0) {
                    cout << "->";
                }
            }
            cout << endl;
            
            cout << "The shortest distance: " << weight << endl;
            
            break;
        }
    }
    
    return true;
}

void ScenicGraph::lay_circuit_planning() {
    cout
    << "===== Lay Circuit Planning =====" << endl
    << "Lay circuit between these spots: " << endl;
    
    vector<int> min_weight;
    vector<Graph_node*> p_list;
    Graph_node *p = &_scenic_spot_list[0];
    Graph_node *q;
    int total_length = 0;
    
    p->flag = true;
    p_list.push_back(p);
    
    while (!this->if_all_nextnode_true(p_list)) {
        min_weight.push_back(0);
        
        for (int i = 0; i < p_list.size(); i++) {
            q = p_list[i];
            
            for (vector<edge>::iterator it = q->edge.begin(); it != q->edge.end(); it++) {
                if ((it->weight < min_weight.back() || min_weight.back() == 0) && it->next->flag == false) {
                    min_weight.back() = it->weight;
                    p->present_it = it;
                }
            }
        }
        
        p = p->present_it->next;
        p->flag = true;
        p_list.push_back(p);
    }
    
    for (int i = 0; i < p_list.size() - 1; i++) {
        cout << p_list[i]->name + " - " + p_list[i + 1]->name << "  " << min_weight[i] << endl;
        total_length += min_weight[i];
    }
    
    cout << "The total length of laying circuit is: " << total_length << endl;
}

void ScenicGraph::reset_flag() {
    for (vector<Graph_node>::iterator it_node = _scenic_spot_list.begin(); it_node != _scenic_spot_list.end(); it_node++) {
        it_node->flag = false;
        
        for (vector<edge>::iterator it_first_edge = it_node->edge.begin(); it_first_edge != it_node->edge.end(); it_first_edge++) {
            it_first_edge->flag = false;
        }
    }
}

bool ScenicGraph::if_edge_true(int spot_num) {
    for (vector<edge>::iterator it = _scenic_spot_list[spot_num].edge.begin(); it != _scenic_spot_list[spot_num].edge.end(); it++) {
        if (it->flag == false) {
            return false;
        }
    }
    
    return true;
}

bool ScenicGraph::if_nextnode_true(Graph_node *p) {
    for (vector<edge>::iterator it = p->edge.begin(); it != p->edge.end(); it++) {
        if (it->next->flag == false) {
            return false;
        }
    }
    
    return true;
}

bool ScenicGraph::if_all_nextnode_true(vector<Graph_node*> p_list) {
    for (int i = 0; i < p_list.size(); i++) {
        for (vector<edge>::iterator it = p_list[i]->edge.begin(); it != p_list[i]->edge.end(); it++) {
            if (it->next->flag == false) {
                return false;
            }
        }
    }
    
    return true;
}