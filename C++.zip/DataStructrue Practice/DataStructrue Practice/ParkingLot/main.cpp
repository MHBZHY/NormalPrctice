//
//  main.cpp
//  DataStructrue Practice
//
//  Created by zhy on 15/10/13.
//  Copyright © 2015年 zhy. All rights reserved.
//

#include "main.hpp"

int main() {
	ParkingLot mainParkingLot;
	string originalStr;
	string option;
	
	cout << "===== Parking Lot Management =====" << endl << endl;
	
start:
	cout
	<< "1. Vehicle entry" << endl
	<< "2. Vehicle leaving" << endl
	<< "3. View parking lot" << endl
	<< "4. Quit" << endl
	<< "Please enter an option number: ";
	
	cin >> originalStr;
	option = originalStr[0];
	
	cout << endl;
	switch (stringToNum<int>(option)) {
		case 1:
			mainParkingLot.enter();
			break;
			
		case 2:
			mainParkingLot.leave();
			break;
			
		case 3:
			mainParkingLot.show();
			break;
			
		case 4:
			return 0;
			
		default:
			cout << "Input error!" << endl;
			break;
	}
	
	cout << endl;
	goto start;
	
	return 0;
}

//convert string to number
template <class T>
T stringToNum(const string& str)
{
	istringstream iss(str);
	T num;
	
	iss >> num;
	
	return num;
}
