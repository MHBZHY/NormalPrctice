//
//  ParkingLot.cpp
//  DataStructrue Practice
//
//  Created by zhy on 15/10/13.
//  Copyright © 2015年 zhy. All rights reserved.
//

#include "main.hpp"

void ParkingLot::enter() {
	string registration_number;
	int parking_time;
	Vehicle newVehicle;
	
	cout << "----- Vehicle entry -----" << endl;
	
	cout << "Please enter the registration number: ";
	cin >> registration_number;
	getchar();
	
	cout << "Please enter the parking time: ";
	cin >> parking_time;
	getchar();
	
	newVehicle.registration_number = registration_number;
	newVehicle.parking_time = parking_time;
	time(&newVehicle.parking_time_system);
	
	if (this->queue_parkinglot.size() < 100) {
		this->queue_parkinglot.push_front(newVehicle);
	}
	else {
		if (this->queue_reserve_parkinglot.size() < 10) {
			this->queue_reserve_parkinglot.push_front(newVehicle);
		}
		else {
			cout << "The main and reserve parking lots are all full!" << endl;
		}
	}
}

void ParkingLot::leave() {
	time_t leaving_time;
	long stay_time;
	
	cout << "----- Vehicle leaving -----" << endl;
	
	if (this->queue_parkinglot.empty()) {
		cout << "There is no vehicle in parking lot!" << endl;
		return;
	}
	
	time(&leaving_time);
	stay_time = leaving_time - this->queue_parkinglot.front().parking_time_system;
	
	cout
	<< "Car " << this->queue_parkinglot.front().registration_number << " leaving time: " << stay_time + this->queue_parkinglot.front().parking_time << endl
	<< "Fee: " << stay_time * 0.8 << endl;
	
	this->queue_parkinglot.pop_front();
	
	if (!this->queue_reserve_parkinglot.empty()) {
		this->queue_parkinglot.push_front(this->queue_reserve_parkinglot.front());
		this->queue_reserve_parkinglot.pop_front();
	}
}

void ParkingLot::show() {
	Vehicle p;
	
	cout << "----- View parking lot -----" << endl;
	
	for (int i = 0; i < this->queue_parkinglot.size(); i++) {
		cout
		<< "Registration number: " << this->queue_parkinglot[i].registration_number
		<< " Parking time: " << this->queue_parkinglot[i].parking_time << endl;
	}
}