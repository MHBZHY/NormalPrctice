//
//  main.hpp
//  DataStructrue Practice
//
//  Created by zhy on 15/10/13.
//  Copyright © 2015年 zhy. All rights reserved.
//

#ifndef main_hpp
#define main_hpp

#include <stdio.h>
#include <iostream>
#include <sstream>
#include <string>
#include <deque>
#include <array>
#include <time.h>
using namespace std;

struct Vehicle {
	string registration_number;
	int parking_time;
	time_t parking_time_system;
};

class ParkingLot {
	deque<Vehicle> queue_parkinglot;
	deque<Vehicle> queue_reserve_parkinglot;
	
public:
	void enter();
	void leave();
	void show();
};

template <class T>
T stringToNum(const string& str);

#endif /* main_hpp */
