//
//  Matrix.hpp
//  DataStructrue Practice
//
//  Created by zhy on 15/10/30.
//  Copyright © 2015年 zhy. All rights reserved.
//

#ifndef Matrix_hpp
#define Matrix_hpp

#include <string>
#include <array>
#include <iostream>
#include <fstream>
using namespace std;

class Matrix {
private:
	int **matrix;
	
public:
	Matrix(string in_path);
	Matrix(int **matrix);
    
    void exed();
	
	int num;
	
	void rclosure();
	void sclosure();
	void tclosure();
	
	void convert_to_hasse();
	bool IsReflexive();
	bool IsIrreflexive();
	bool IsSymmetric();
	bool IsAsymmetric();
	bool IsAntisymmetric();
	bool IsTransitive();
	bool IsEquivalence();
	void showMatrix();
	void EquivalenceClass();
};

#endif /* Matrix_hpp */
