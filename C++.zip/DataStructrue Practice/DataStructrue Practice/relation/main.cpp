#include "Matrix.hpp"

void Matrix::exed() {
    int **matrix;
    
    this->num = 16;
	
	matrix[0][1] = matrix[5][2] = matrix[3][11] = matrix[10][4] = matrix[6][12] = matrix[15][1] = matrix[13][8] = matrix[3][5] = matrix[4][0] = matrix[9][8] = matrix[8][12] = matrix[6][7] = matrix[12][9] = matrix[10][15] = matrix[2][3] = 1;
    
    this->matrix = new int*[this->num];
    
    for(int i = 0; i < this->num; i ++)
    {
        this->matrix[i] = new int[this->num];
    }
    
	Matrix ma((int**)matrix);
	
	ma.rclosure();
	ma.sclosure();
	ma.tclosure();
	
	ma.showMatrix();
}

int main() {
//	for(int i = 0; i < 6; i ++) {
//		Matrix *p;
//		string in_path = "test";
//		
//		in_path += i + 49;
//		in_path += ".txt";
//		
//		p = new Matrix(in_path);
//		p->showMatrix();
//		
////		//test
////		if(p->IsReflexive())
////			cout<<"The relation is reflexive"<<endl;
////		if(p->IsIrreflexive())
////			cout<<"The relation is irreflexive"<<endl;
////		if(p->IsSymmetric())
////			cout<<"The relation is symmetric"<<endl;
////		if(p->IsAsymmetric())
////			cout<<"The relation is asymmetric"<<endl;
////		if(p->IsAntisymmetric())
////			cout<<"The relation is antisymmetric"<<endl;
////		if(p->IsTransitive())
////			cout<<"The relation is transitive"<<endl;
//
////		p->convert_to_hasse();
//	}
	
	exed();
	
	return 0;
}