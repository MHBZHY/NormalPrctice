//
//  Matrix.cpp
//  DataStructrue Practice
//
//  Created by zhy on 15/10/30.
//  Copyright © 2015年 zhy. All rights reserved.
//

#include "Matrix.hpp"

Matrix::Matrix(string in_path) {
	ifstream in(in_path);
	
	if(!in) {
		cout <<"Fail to open " << in_path;
		return;
	}
	
	in >> this->num;
	this->matrix = new int*[this->num];
	
	for(int i = 0; i < this->num; i ++)
	{
		this->matrix[i] = new int[this->num];
		for(int j = 0; j < this->num; j ++)
			in>>matrix[i][j];
	}
}

Matrix::Matrix(int **matrix) {
	this->matrix = matrix;
}

void Matrix::showMatrix()
{
	for(int i = 0; i < this->num; i ++)
	{
		for(int j = 0; j < this->num; j ++)
			cout<<matrix[i][j] <<" ";
		cout<<endl;
	}
	cout<<endl;
}

bool Matrix::IsReflexive()
{
	for(int i = 0; i < this->num; i ++)
		if(!matrix[i][i])
			return false;
	return true;
}

bool Matrix::IsIrreflexive()
{
	for(int i = 0; i < this->num; i ++)
		if(matrix[i][i])
			return false;
	return true;
}

bool Matrix::IsSymmetric()
{
	for(int i = 0; i < this->num; i ++)
		for(int j = 0; j < this->num; j ++)
			if(matrix[i][j] != matrix[j][i])
				return false;
	return true;
}

bool Matrix::IsAsymmetric()
{
	return !IsSymmetric();
}

bool Matrix::IsAntisymmetric()
{
	for(int i = 0; i < this->num; i ++)
		for(int j = 0; j < this->num; j ++)
			if(matrix[i][j] && matrix[j][i] && i != j)
				return false;
	return true;
}

bool Matrix::IsTransitive()
{
	for(int k = 0; k < this->num; k ++)
		for(int i = 0; i < this->num; i ++)
			for(int j = 0; j < this->num; j ++)
				if(matrix[i][k] && matrix[k][j] && !matrix[i][j] )
					return false;
	return true;
}

void Matrix::rclosure()
{
	for(int i = 0; i < this->num; i ++)
		this->matrix[i][i] = 1;
}

void Matrix::sclosure()
{
	for(int i = 0; i < this->num; i ++)
		for(int j = 0; j < this->num; j ++)
			if(matrix[i][j] != matrix[j][i])
				matrix[i][j] = matrix[j][i] = 1;
}

void Matrix::tclosure()
{
	for(int k = 0; k < this->num; k ++)
		for(int i = 0; i < this->num; i ++)
			for(int j = 0; j < this->num; j ++)
				if(matrix[i][k] && matrix[k][j] && !matrix[i][j] )
					matrix[i][j] = 1;
}

bool Matrix::IsEquivalence()
{
	return IsReflexive() && IsSymmetric() && IsTransitive();
}

void Matrix::EquivalenceClass()
{
	for(int i = 0; i < this->num; i ++)
	{
		for(int j = i; j < this->num; j ++)
			if(matrix[i][j])
			{
				cout<<j+1<<" ";
				if(j != i)
					for(int m = 0; m < this->num; m ++)
						matrix[j][m] = 0;
			}
		cout<<endl;
	}
	cout<<endl;
}

void Matrix::convert_to_hasse() {
	for (int i = 0; i < this->num; i++) {
		for (int j = 0; j < this->num; j++) {
			if (i == j) {
				this->matrix[i][j] = 1;
			}
			
			for (int k = 0; k < this->num; k++) {
				if(matrix[i][j] && matrix[j][k] && !matrix[i][k])
					matrix[i][k] = 1;
			}
		}
	}
	
	for (int i = 0; i < this->num; i++) {
		for (int j = 0; j < this->num; j++) {
			if (i == j) {
				this->matrix[i][j] = 0;
			}
			
			for (int k = 0; k < this->num; k++) {
				if(matrix[i][j] && matrix[j][k] && matrix[i][k])
					matrix[i][k] = 0;
			}
		}
	}
	
	cout << "hasse" << endl;
	this->showMatrix();
}
