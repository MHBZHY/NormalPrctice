//
//  main.cpp
//  DataStructrue Practice
//
//  Created by zhy on 10/9/15.
//  Copyright © 2015 zhy. All rights reserved.
//

#include "Header.hpp"

int main(int argc, const char * argv[]) {
	string input, rightStr;
	
	cout << "Please input an expression: ";
	cin >> input;
	getchar();
	
	rightStr = changeToRightHandOperatorExpression(input);
	cout << "Your expression's right hand operator expression is: " << rightStr << endl;
	
	cout << "The result is: " << calculate(rightStr) << endl;
	
    return 0;
}

bool isHigherOperator(char ch) {
	return (ch == '*' || ch == '/');
}

bool isLowerOperator(char ch) {
	return (ch == '+' || ch == '-');
}

//convert string to number
template <class T>
T stringToNum(const string& str)
{
	istringstream iss(str);
	T num;
	
	iss >> num;
	
	return num;
}

string changeToRightHandOperatorExpression(string origin) {
	stack<char> solve;
	string rightStr = "";
	
	for (int i = 0; i < origin.length(); i++) {
		//read number into rightStr, until reach operator
		if (isdigit(origin[i]) || origin[i] == '.') {
			while (isdigit(origin[i]) || origin[i] == '.') {
				rightStr += origin[i++];
			}
			
			i--;
			rightStr += '$';		//after every number, add an '$' to divide
		}
		//if it is '+' or '-', we load all type of operators from stack, in order, into rightStr
		else if (isLowerOperator(origin[i])) {
			while (solve.size() && (isLowerOperator(solve.top()) || isHigherOperator(solve.top()))) {
				rightStr += solve.top();
				solve.pop();
			}
			
			solve.push(origin[i]);
		}
		//if it is '*' or '/', we only load '*' or '/' from stack, in order, into rightStr
		else if (isHigherOperator(origin[i])) {
			while (solve.size() && isHigherOperator(solve.top())) {
				rightStr += solve.top();
				solve.pop();
			}
			
			solve.push(origin[i]);
		}
		//if it is ')', pop all the operators until reach '('
		else if (origin[i] == ')') {
			while (solve.top() != '(') {
				rightStr += solve.top();
				solve.pop();
			}
			
			solve.pop();
		}
		//if something else reserved(ex: '(' and ')'), push it into stack
		else {
			solve.push(origin[i]);
		}
	}
	
	//load reserved symbols into rightStr
	while (solve.size()) {
		rightStr += solve.top();
		solve.pop();
	}
	
	return rightStr;
}

double calculate(string rightStr) {
	stack<double> result;
	string calculateStr;
	double calculateDouble = 0.0;
	
	for (int i = 0; i < rightStr.length(); i++) {
		calculateStr = "";
		
		//if it is number between 0~9, or '.', load it into calculateStr
		if (isdigit(rightStr[i]) || rightStr[i] == '.') {
			while (isdigit(rightStr[i]) || rightStr[i] == '.') {
				calculateStr += rightStr[i++];
			}
			//convert string to number, then push into stack. Because of '$', we need not to do i--
			result.push(stringToNum<double>(calculateStr));
		}
		//calculate expression follow the rule: when reach operator, pop two number to calculate, then push back to stack
		else {
			switch (rightStr[i]) {
				case '+':
					calculateDouble = result.top(); result.pop(); calculateDouble += result.top(); result.pop(); result.push(calculateDouble);
					break;
				case '-':
					calculateDouble = result.top(); result.pop(); calculateDouble = result.top() - calculateDouble; result.pop(); result.push(calculateDouble);
					break;
				case '*':
					calculateDouble = result.top(); result.pop(); calculateDouble *= result.top(); result.pop(); result.push(calculateDouble);
					break;
				case '/':
					calculateDouble = result.top(); result.pop(); calculateDouble = result.top() / calculateDouble; result.pop(); result.push(calculateDouble);
					break;
					
				default:
					break;
			}
		}
	}
	
	//return calculate result
	return result.top();
}