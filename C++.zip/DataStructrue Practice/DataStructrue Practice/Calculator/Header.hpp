//
//  Header.h
//  DataStructrue Practice
//
//  Created by zhy on 10/9/15.
//  Copyright © 2015 zhy. All rights reserved.
//

#include <iostream>
#include <string>
#include <stack>
#include <fstream>
#include <sstream>
using namespace std;

bool isHigherOperator(char ch);
bool isLowerOperator(char ch);
template <class T>
T stringToNum(const string& str);

string changeToRightHandOperatorExpression(string origin);
double calculate(string rightStr);