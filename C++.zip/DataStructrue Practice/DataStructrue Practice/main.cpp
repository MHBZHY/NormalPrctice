//
//  main.cpp
//  DataStructrue Practice
//
//  Created by zhy on 15/11/11.
//  Copyright © 2015年 zhy. All rights reserved.
//

#include "Graph.hpp"

int main() {
    ScenicGraph scenic_map("/Developer/Xcode Project/DataStructrue Practice/DataStructrue Practice/vertex.txt", "/Developer/Xcode Project/DataStructrue Practice/DataStructrue Practice/edge.txt");
    
    while (1) {
        cout
        << "===== Scenic Information Management =====" << endl
        << "1. Create Scenic Spot Graph" << endl
        << "2. Query Spot Information" << endl
        << "3. Navigate Tourism Spot" << endl
        << "4. Search Shortest path" << endl
        << "5. Lay Circuit Planning" << endl
        << "0. Exit" << endl
        << "Please input options(0~5): ";
        
        int option;
        cin >> option;
        getchar();
        
        switch (option) {
            case 0: exit(0); break;
            case 1: scenic_map.create_scenic_spot_graph(); break;
            case 2:
                if (!scenic_map.query_spot_information()) {
                    cout << "Input error!" << endl;
                }
                break;
            case 3:
                if (!scenic_map.navigate_tourism_spot()) {
                    cout << "Input error!" << endl;
                }
                break;
            case 4:
                if (!scenic_map.search_shortest_path()) {
                    cout << "Input error!" << endl;
                }
                break;
            case 5: scenic_map.lay_circuit_planning(); break;
                
            default:
                break;
        }
    }
    
    return 0;
}
