//
//  main.cpp
//  C++ project
//
//  Created by zhy on 15/9/25.
//  Copyright © 2015年 zhy. All rights reserved.
//

#include "LinkedList.hpp"
#include "LinkedList.cpp"

int main() {
    
    LinkedList<int> *ll = new LinkedList<int>();
    
    ll = &ll->insert(1, 1);
    ll = &ll->insert(1, 2);
    ll = &ll->insert(1, 3);
    ll = &ll->insert(1, 4);
    ll = &ll->insert(1, 5);
    
    ll->toString();
    cout << endl;
    
    int deleteValue;
    
    ll = &ll->Delete(1, deleteValue);
    
    cout << "deletevalue: " << deleteValue << endl;
    ll->toString();
    
    int index = ll->search(4);
    cout << "index: " << index << endl;
    
    bool isFind;
    int findValue;
    
    isFind = ll->find(2, findValue);
    
    cout << "isfind: " << isFind << endl
    << "findvalue: " << findValue << endl;
    
    return 0;
}