//
//  LinkedList.cpp
//  C++ project
//
//  Created by zhy on 15/9/25.
//  Copyright © 2015年 zhy. All rights reserved.
//

#include "LinkedList.hpp"

template<class T>
LinkedList<T>::~LinkedList()
{
    Node<T> *p = head;
    
    while (p != nullptr)
    {
        head = p->next;
        delete p;
        p = head;
    }
}

template <class T>
bool LinkedList<T>::find(int index, T &value)
{
    Node<T> *p = head;
    
    while (p != nullptr)
    {
        if (p->index == index)
        {
            value = p->value;
            return true;
        }
        
        p = p->next;
    }
    
    return false;
}

template<class T>
int LinkedList<T>::search(T value)
{
    Node<T> *p = head;
    
    while (p != nullptr)
    {
        if (p->value == value)
        {
            return p->index;
        }
        
        p = p->next;
    }
    
    return 0;
}

template<class T>
LinkedList<T>& LinkedList<T>::Delete(int index, T &value)
{
    // TODO: 在此处插入 return 语句
    Node<T> *p = head;
    Node<T> *q = nullptr;
    
    if (index <= 0 || index > length)
    {
        return *this;
    }
    else
    {
        if (p->next->index == index)
        {
            if (p->next->next != nullptr)
            {
                q = p->next;
                p->next = p->next->next;
            }
            
            value = p->value;
            delete q;
            
            while (p->next != nullptr) {
                p->next->index--;
                p = p->next;
            }
        }
    }
    
    return *this;
}

template <class T>
LinkedList<T>& LinkedList<T>::insert(int index, T value)
{
    Node<T> *p = head;
    Node<T> *q = nullptr;
    
    if (index <= 0)
    {
        return *this;
    }
    else if (index > length)
    {
        while (p->next != nullptr)
        {
            p = p->next;
        }
        
        p->next = new Node<T>(length + 1, value);
        
        length++;
    }
    else
    {
        if (p->next->index == index) {
            q = new Node<T>(index, value);
            q->next = p->next;
            q->next->index++;
            p->next = q;
            p = q->next;
            
            while (p->next != nullptr) {
                p->next->index++;
                p = p->next;
            }
        }
    }
    
    return *this;
}

template <class T>
void LinkedList<T>::toString() {
    Node<T> *p = head->next;
    
    while (p != nullptr) {
        cout << p->value;
        p = p->next;
    }
}