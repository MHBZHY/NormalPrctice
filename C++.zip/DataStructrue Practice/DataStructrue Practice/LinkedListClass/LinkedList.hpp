//
//  LinkedList.hpp
//  C++ project
//
//  Created by zhy on 15/9/25.
//  Copyright © 2015年 zhy. All rights reserved.
//

#ifndef LinkedList_hpp
#define LinkedList_hpp

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>

using namespace std;

template <class T>
class LinkedList;

template <class T>
class Node {
    friend LinkedList<T>;
    
private:
    T value;
    int index;
    Node<T> *next;
    
public:
    Node(int index, T value) { this->index = index; this->value = value; next = nullptr; };
};

template <class T>
class LinkedList {
    
private:
    Node<T> *head;
    int length;
    
public:
    LinkedList() { head = new Node<T>(0, T()); length = 0; }
    LinkedList(Node<T> *head) { this->head = head; }
    ~LinkedList();
    
    bool isEmpty() { return head == nullptr; }
    
    int getLength() { return length; }
    
    bool find(int index, T &value);
    
    int search(T value);
    
    LinkedList<T> &Delete(int index, T &value);
    
    LinkedList<T> &insert(int index, T value);
    
    void toString();
};

#endif /* LinkedList_hpp */
