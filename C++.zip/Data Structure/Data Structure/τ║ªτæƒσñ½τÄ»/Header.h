//
//  Header.h
//  Data Structure
//
//  Created by zhy on 15/9/21.
//  Copyright (c) 2015年 zhy. All rights reserved.
//

#ifndef Data_Structure_Header_h
#define Data_Structure_Header_h

#include<stdio.h>
#include<stdlib.h>

typedef struct Joseph {
	int password;
	int order;
	struct Joseph *next;
}Joseph;

void execute(Joseph *head);

#endif
