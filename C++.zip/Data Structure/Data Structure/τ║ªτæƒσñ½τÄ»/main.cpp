//
//  main.cpp
//  Data Structure
//
//  Created by zhy on 15/9/21.
//  Copyright (c) 2015年 zhy. All rights reserved.
//

#include <iostream>
#include "Header.h"

int main(int argc, const char * argv[]) {
	// insert code here...
	int passwordArray[] = {3, 1, 7, 2, 4, 8, 4};
	
	Joseph *head = (Joseph*)malloc(sizeof(Joseph));
	
	head->password = passwordArray[0];
	head->order = 1;
	head->next = (Joseph*)malloc(sizeof(Joseph));
	
	Joseph *p = head;
	
	for (int i = 1; i < 7; i++) {
		p = p->next;
		p->order = i + 1;
		p->password = passwordArray[i];
		p->next = (Joseph*)malloc(sizeof(Joseph));
	}
	
	p->next = head;		//male a circle
	
	execute(head);		//game start
	
    return 0;
}

void execute(Joseph *head) {
	int m = 20;
	int count = 0;
	
loop:
	//execute 18 times, because of this block does not count the first people, and at every time. We will get the people's front one before we let it get out
	for (int i = 0; i < m - 2; i++) {
		head = head->next;
	}
	
	Joseph *p = head->next;
	
	printf("%d, ", p->order);
	m = p->password;		//update value of m
	
	head->next = p->next;
	free(p);					//get out
	
	head = head->next;		//start from next people
	
	count++;
	if (count < 7) {
		goto loop;
	}
}