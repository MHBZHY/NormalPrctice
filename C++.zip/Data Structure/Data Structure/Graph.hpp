//
//  Graph.hpp
//  Data Structure
//
//  Created by zhy on 15/11/2.
//  Copyright © 2015年 zhy. All rights reserved.
//

#ifndef Graph_hpp
#define Graph_hpp

#include <iostream>
#include <string>
#include <vector>
#include <stack>
#include <fstream>
using namespace std;

typedef struct g_node {
	struct g_node *out;
	int vertex;
	int weight;
    bool flag = false;
}Graph_node;

class Graph {
	vector<Graph_node> _vector_vertex_list;
	int _num_of_vertexs = 0, _num_of_edges = 0;
    
public:
	Graph(string path);
	
	void to_string();
    bool DFS(int value);
};

#endif /* Graph_hpp */
