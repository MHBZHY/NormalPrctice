//
//  Header.h
//  Data Structure
//
//  Created by zhy on 15/9/24.
//  Copyright (c) 2015年 zhy. All rights reserved.
//

#ifndef Data_Structure_Header_h
#define Data_Structure_Header_h

#include <iostream>
#include <string>
using namespace std;

typedef struct linearList {
	int value;
	struct linearList *next;
}linearList;

void Delete(linearList *head, int start, int end);

#endif
