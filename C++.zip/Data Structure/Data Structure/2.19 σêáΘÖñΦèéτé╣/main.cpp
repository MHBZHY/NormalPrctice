//
//  main.cpp
//  Data Structure
//
//  Created by zhy on 15/9/24.
//  Copyright (c) 2015年 zhy. All rights reserved.
//

#include <stdio.h>
#include "Header.h"

int main() {
	return 0;
}

void Delete(linearList *head, int start, int end) {
	linearList *p = head, *st = nullptr;
	
	for (int i = 0; p->next != nullptr; i++) {		//times: start
		if (i == start) {
			st = p;
			
			for (int j = i; j <= end; j++) {		//times: end - start
				free(p);
				p = st->next;
				st = p;
				
				if (j == end) {
					break;
				}
			}
		}
	}
}
//time complexity: O(start * (en - start))