//
//  Graph.cpp
//  Data Structure
//
//  Created by zhy on 15/11/2.
//  Copyright © 2015年 zhy. All rights reserved.
//

#include "Graph.hpp"

Graph::Graph(string path) {
    ifstream in(path);
	
    in >> _num_of_vertexs >> _num_of_edges;
    
    while (in.eof()) {
        _vector_vertex_list.push_back(*new Graph_node());
        in >> _vector_vertex_list.back().vertex;
    }
}

void Graph::to_string() {
}

bool Graph::DFS(int value) {
    stack<Graph_node*> s_temp;
    Graph_node *p = &this->_vector_vertex_list[0];
    
    while (p != nullptr || !s_temp.empty()) {
        while (p->flag == false && p != nullptr) {
            p->flag = true;
            cout << p->vertex << "->";
            s_temp.push(p);
            p = p->out;
        }
        
        if (!s_temp.empty()) {
            p = s_temp.top();
            s_temp.pop();
        }
    }
    
    return false;
}