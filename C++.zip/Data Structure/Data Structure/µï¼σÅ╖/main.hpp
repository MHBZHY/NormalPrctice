//
//  main.hpp
//  Data Structure
//
//  Created by zhy on 10/8/15.
//  Copyright © 2015 zhy. All rights reserved.
//

#ifndef main_hpp
#define main_hpp

#include <stdio.h>
#include <iostream>
#include <string>

using namespace std;

#endif /* main_hpp */
