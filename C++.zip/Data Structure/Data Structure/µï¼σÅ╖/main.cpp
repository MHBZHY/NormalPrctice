//
//  main.cpp
//  Data Structure
//
//  Created by zhy on 10/8/15.
//  Copyright © 2015 zhy. All rights reserved.
//

#include "main.hpp"

int main() {
	string str = "", strLeft = "";
	int right = 0;
	
	cout << "Input string." << endl;
	cin >> str;
	
	for (int i = 0; i < str.length(); i++) {
		switch (str[i]) {
			case '{':
				strLeft += '{';
				break;
			case '}':
				right++;
				if (strLeft[strLeft.length() - 1] != '{') {
					cout << "error!" << endl;
				};
				break;
			case '(':
				strLeft += '(';
				break;
			case ')':
				right++;
				if (strLeft[strLeft.length() - 1] != '(') {
					cout << "error!" << endl;
				};
				break;
			case '[':
				strLeft += '[';
				break;
			case ']':
				right++;
				if (strLeft[strLeft.length() - 1] != '[') {
					cout << "error!" << endl;
				};
				break;
				
			default:
				break;
		}
	}
	
	if (strLeft.length() != right) {
		cout << "error!" << endl;
	}
}