//
//  main.cpp
//  Data Structure
//
//  Created by zhy on 15/12/16.
//  Copyright © 2015年 zhy. All rights reserved.
//

#include "main.hpp"

#include"Assert.h"
template<typedef E>class heap{
private:
	int* Heap;
	int n;
	int maxSize;
	
	void shiftDown(int pos){
		while (!isLeaf(pos)){
			int left = this->leftChild(pos);
			int right = this->rightChild(pos);
			if (right<n&&Heap[right]>Heap[left])
				left = right;
			if (Heap[left] < Heap[pos]) return;
			swap(Heap[left], Heap[pos]);
			pos = left;
		}
	}
public:
	heap(int* Heap, int n, int maxSize){
		this->Heap = Heap;
		this->n = n;
		this->maxSize = maxSize;
	}
	
	int size() const{ return this->n; }
	
	bool isLeaf(int pos) const{ return (pos > n / 2) && (pos < n); }
	
	int leftChild(int pos) const{ return 2 * pos + 1; }
	
	int rightChild(int pos) const{ return 2 * pos +2; }
	
	int parent(int pos) const{ return (pos  - 1)/2; }
	
	void swap(int& a, int& b){
		int c = a;
		a = b;
		b = c;
	}
	
	void buildHeap(){
		for (int i = n / 2 - 1; i >= 0;i--) shiftDown(i);
	}
	
	void insert(const int& it){
		AssertTrue(n < maxSize, "heap is full");
		int curr = n++;
		heap[curr] = it;
		while ((curr!=0)&&(Heap[curr]>Heap[parent(curr)]))
		{
			swap(Heap[curr], Heap[parent(curr)]);
			curr = parent(curr);
		}
	}
	
	int removefirst(){
		AssertTrue(n > 0, "Heap is empty");
		swap(Heap[0], Heap[--n]);
		if (n != 0)shiftDown(0);
		return Heap[n];
	}
	
	int remove(int pos){
		AssertTrue((pos >= 0) && (pos < n), "bad position");
		if (pos == (n - 1)) n--;
		else{
			while (pos != 0 && (Heap[pos]>Heap[parent(pos)])){
				swap(Heap[pos], Heap[parent(pos)]);
				pos = parent(pos);
			}
			if (n != 0) shiftDown(pos);
		}
		return Heap[n];
	}
	
	
};