//
//  main.hpp
//  Data Structure
//
//  Created by zhy on 15/12/16.
//  Copyright © 2015年 zhy. All rights reserved.
//

#ifndef main_hpp
#define main_hpp

#include <stdio.h>

#endif /* main_hpp */
