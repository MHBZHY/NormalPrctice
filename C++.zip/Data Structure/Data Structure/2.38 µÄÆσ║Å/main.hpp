//
//  main.hpp
//  Data Structure
//
//  Created by zhy on 10/8/15.
//  Copyright © 2015 zhy. All rights reserved.
//

#ifndef main_hpp
#define main_hpp

#include <stdio.h>
#include <iostream>
using namespace std;

template <class T>
class LinkedList;

template <class T>
class Node {
	friend LinkedList<T>;
	
	Node *prior = nullptr, *next = nullptr;
	T data;
	int freq = 0;
	int index;
};

template <class T>
class LinkedList {
	Node<T> *head = new Node<T>;
	int topFreq = 0;
	int length;
	
public:
	LinkedList() { length = 0; }

	bool locate(int L, T x);
	LinkedList<T> &insert(int index, T value);
	void toString();
};

#endif /* main_hpp */
