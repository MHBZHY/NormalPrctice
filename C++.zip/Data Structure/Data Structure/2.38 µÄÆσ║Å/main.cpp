//
//  main.cpp
//  Data Structure
//
//  Created by zhy on 10/8/15.
//  Copyright © 2015 zhy. All rights reserved.
//

#include "main.hpp"

int main() {
	LinkedList<int> *head = new LinkedList<int>;
	
	head->insert(0, 1);
	head->insert(0, 2);
	head->insert(0, 3);
	head->insert(0, 4);
	head->insert(0, 5);
	head->insert(0, 6);
	
	head->toString();
	
	head->locate(0, 1);
	head->locate(3, 4);
	
	head->toString();
	
	return 0;
}

template <class T>
bool LinkedList<T>::locate(int L, T data) {
	Node<T> *p = head;
	
	for (int i = 0; p->next != nullptr; i++) {
		if (i == L) {
			if (p->data != data) {
				return false;
			}
			else {
				p->freq++;
				
				if (p->freq >= topFreq) {
					if (topFreq != 0) {
						p->prior->next = p->next;
						p->next->prior = p->prior;
						
						p->prior = head->prior;
						p->next = head;
						head->prior->next = p;
						head->prior = head;
					}
					
					head = p;
					topFreq = p->freq;
				}
				else {
					if (topFreq > 1) {
						for (Node<T> *q = head; q->next != nullptr; q = q->next) {
							if (p->freq >= q->freq) {
								p->prior->next = p->next;
								p->next->prior = p->prior;
								
								p->prior = q->prior;
								p->next = q;
								q->prior->next = p;
								q->prior = q;
							}
						}
					}
				}
			}
		}
	}
	
	return true;
}

template <class T>
LinkedList<T>& LinkedList<T>::insert(int index, T value)
{
	Node<T> *p = head;
	Node<T> *q = nullptr;
	
	if (index <= 0)
	{
		return *this;
	}
	else if (index > length)
	{
		while (p->next != nullptr)
		{
			p = p->next;
		}
		
		p->next = new Node<T>;
		
		length++;
	}
	else
	{
		if (p->next->index == index) {
			q = new Node<T>;
			q->next = p->next;
			q->next->index++;
			p->next = q;
			p = q->next;
			
			while (p->next != nullptr) {
				p->next->index++;
				p = p->next;
			}
		}
	}
	
	return *this;
}

template <class T>
void LinkedList<T>::toString() {
	Node<T> *p = head->next;
	
	while (p != nullptr) {
		cout << p->data;
		p = p->next;
	}
}