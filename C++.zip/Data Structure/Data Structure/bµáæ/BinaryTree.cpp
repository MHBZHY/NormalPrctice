//
//  BinaryTree.cpp
//  Data Structure
//
//  Created by zhy on 15/10/15.
//  Copyright © 2015年 zhy. All rights reserved.
//

#include "BinaryTree.hpp"

template <class T>
BinaryTree<T>::BinaryTree() {
	this->recursionAddNode(this->root);
}

template <class T>
void BinaryTree<T>::recursionAddNode(BinaryTreeNode<T> *pointer) {
	BinaryTreeNode<T> newNode;
	T data;
	
	cout << "Input data: ";
	cin >> data;
	getchar();
	
	if (data == '#') {
		pointer = nullptr;
	}
	else {
		pointer = new BinaryTreeNode<T>();
		pointer->data = data;
		pointer->recursionAddNode(pointer->lChild);
		pointer->recursionAddNode(pointer->RChild);
	}
}

template <class T>
void BinaryTree<T>::preOrder() {
	stack<BinaryTreeNode<T>> temp;
	BinaryTreeNode<T> *p = this->root;
	
	while (temp.empty() || p != nullptr) {
		while (p != nullptr) {
			temp.push(p);
		}
	}
	
}