//
//  main.cpp
//  Data Structure
//
//  Created by zhy on 15/10/15.
//  Copyright © 2015年 zhy. All rights reserved.
//

#include "BinaryTree.hpp"

int main() {
	
	return 0;
}