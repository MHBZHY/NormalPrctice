//
//  BinaryTree.hpp
//  Data Structure
//
//  Created by zhy on 15/10/15.
//  Copyright © 2015年 zhy. All rights reserved.
//

#ifndef BinaryTree_hpp
#define BinaryTree_hpp

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <stack>
using namespace std;

template <class T>
struct BinaryTreeNode {
	T data;
	BinaryTreeNode<T> *lChild = nullptr, *rChild = nullptr;
};

template <class T>
class BinaryTree {
	BinaryTreeNode<T> *root;
	
public:
	BinaryTree();
	void recursionAddNode(BinaryTreeNode<T> *root);
	void preOrder();
	void inOrder();
	void postOrder();
};

#endif /* BinaryTree_hpp */
