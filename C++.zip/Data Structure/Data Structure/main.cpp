//#include <stdlib.h>
//#include <iostream>
//#include <vector>
//#include <functional>
//#include <algorithm>
//
//using namespace std;
//
//class Custom {
//	int integer;
//	
//public:
//	void print() const {
//		cout << 1 << endl;
//	}
//};
//
//int main() {
//	vector<int> text_vector = {1, 2, 3, 4, 5};
//	
//	for_each(text_vector.begin(), text_vector.end(), mem_fun(&Custom::print));
//	
//	return 0;
//}

#include <iostream>
#include <vector>
#include <functional>
#include <algorithm>

class Door {
	
	
public:
	void open() const {
		std::cout << "open" << std::endl;
	}
};

class DoorController {
	std::vector<int> test = {1, 2, 3, 4, 5};
	
public:
	void open() const {
		std::for_each(test.begin(), test.end(), std::mem_fun_ref(&Door::open));
	}
};

int main() {
	
	DoorController door;
	door.open();
}