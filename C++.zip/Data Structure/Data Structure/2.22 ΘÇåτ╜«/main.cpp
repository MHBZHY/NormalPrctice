//
//  main.cpp
//  Data Structure
//
//  Created by zhy on 10/8/15.
//  Copyright © 2015 zhy. All rights reserved.
//

#include "main.hpp"

int main() {
	return 0;
}

void against(LinkedList *head) {
	LinkedList *p = head, *q = head->next, *r = head->next->next;
	
	for (int i = 0; r != nullptr; i++) {
		q->next = p;
		p = q;
		q = r;
		r = r->next;
	}
	
	if (q != nullptr) {
		q->next = p;
		head->next = nullptr;
	}
	else {
		printf("just one");
	}
}