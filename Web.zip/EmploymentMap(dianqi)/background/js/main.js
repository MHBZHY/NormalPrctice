/**
 * Created by zhy on 16/4/14.
 */

//flag: 0 company, 1 student
var flag = 1;
var tempItems = null;

//解析用key
var compKeys = ["c_id", "c_name", "c_province", "c_city", "c_property", "c_website", "is_vital", "stu_num"];
var stuKeys = ["stu_id", "stu_name", "pwd", "stu_class", "graduate_time", "weixin_qq", "phone", "com_name"];


$(function () {
    //生成table
    $.geneStuTable();

    //首先显示学生信息
    $.getAndShowData("get_all_stu", stuKeys, function (source) {
        $.addAutoComplete(source);
    });
    
    //左边栏点击动画
    var lis = $("div.main div.cols#left ul li");

    lis.click(function () {
        var clicked = $(this);

        $.each(lis, function (index, value) {
            //删除原选中状态
            if ($(value).hasClass("chosen")) {
                //检验是否前两个
                if (value == lis[0] || value == lis[1]) {
                    //暂存按钮
                    tempItems = $("table.info").nextAll().clone();
                }

                $(value).removeClass("chosen");
            }

            if ($(value)[0] == clicked[0]) {
                //改变右页内容
                $.geneByParentNodeAndId($("div.main div.cols#right"), index, tempItems);

                if (index == 0) {
                    $.getAndShowData("all_com", compKeys, function (source) {
                        $.addAutoComplete(source);
                    });

                    //再注册
                    $.tableRegisterEvent();
                }
                else if (index == 1) {
                    $.getAndShowData("get_all_stu", stuKeys, function (source) {
                        $.addAutoComplete(source);
                    });

                    //再注册
                    $.tableRegisterEvent();
                }

                //改变flag
                flag = index;
            }
        });

        //添加选中状态
        $(this).addClass("chosen");
    });

    //注册事件
    $.registerEvents();
    $.tableRegisterEvent();
});

//所有需要再注册的事件
$.registerEvents = function () {
    //删除
    $.deleteRow();
    //插入
    $.insertRow();
    //翻页
    $.changePage();
    //右上搜索框
    $.search();
    //页码点击事件
    $.pageTapEvent();
};

$.tableRegisterEvent = function () {
    //表格可编辑
    $.editEvent();
    //tr可选中
    $.chooseTR();
};

//页码点击事件
$.pageTapEvent = function () {
    $("p.pages").click(function () {
        var beforeP = $(this).prev();
        
        beforeP.after("<input type='text' class='pages' style='color: black; border: 1px solid lightgray;' onblur='$.pageBlur(this)' value='" + presentPageNum + "'>");
        beforeP.next().focus();
        
        this.remove();
    })
};

$.pageBlur = function (self) {
    var str = $.goToPointedPage($(self).val());
    var beforeP = $(self).prev();
    
    self.remove();
    beforeP.after("<p class='pages'>" + str + "</p>");

    //再注册
    $.pageTapEvent();
};

$.deleteRow = function () {
    //删除按钮事件
    $("div.main input.delete").click(function () {
        //发送删除请求
        var id = $($("div.main table.info tr.chosen td")[0]).html();

        if (flag == 0) {
            $.deleteCompany(id);
        }
        else {
            $.deleteStudent(id);
        }
    });
};

$.insertRow = function () {
    //插入按钮事件
    $("div.main div.cols#right > input.insert").click(function () {
        if (flag == 0) {
            $.insertCompany(function () {
                var tr = $($("table.info tr")[
                    (tempData[tempData.length - 1].length != 0)?tempData[tempData.length - 1].length:10
                    ]);
                tr.trigger("click");

                //自动获得第二个单元格的焦点
                $(tr.children("td")[1]).trigger("dblclick");
            })
        }
        else if (flag == 1) {
            $.insertStudent(function () {
                //自动获得第一个单元格的焦点
                var tr = $($("table.info tr")[tempData[tempData.length - 1].length]);
                tr.trigger("click");

                $(tr.children("td")[0]).trigger("dblclick");
            })
        }
    });
};

$.changePage = function () {
    //下一步按钮事件
    $("div.buttons input").click(function () {
        if ($(this).hasClass("next")) {
            $.increasePageNum($("p.pages"));
        }
        else {
            $.decreasePageNum($("p.pages"));
        }
    });
};

//搜索按钮事件
$.search = function () {
    $("div.cols#right div#rightTitle input[type=submit]").click(function () {
        $.showDataInTable(
            $.searchDataWithKey($(this).siblings("input[type=text]").val())
        )
    });
};

$.editEvent = function () {
    //表格双击修改事件
    $("table.info td").dblclick(function () {
        $(this).html("<input type='text' value='" + $(this).html() + "' style='width: 100%; height: 100%; border: 0; border-radius: 0; color: black;' onblur='$.blurEvent(this)' origval='" + $(this).html() + "'>");

        //自动获取焦点
        $(this).children()[0].focus();

        //判断是否学生最后一栏
        if (flag == 1) {
            var tds = $(this).parent().children();
            var td = this;

            if (td == tds[tds.length - 1]) {
                $.getData("all_com", compKeys, undefined, function (source) {
                    $(td).children("input").autocomplete({
                        source: source
                    })
                });
            }
        }
    })
};

$.blurEvent = function (self) {
    var td = $(self).parent();
    var tr = td.parent();
    var preId;

    // var inner = tr.children()[0].children();
    if (td[0] != tr.children()[0]) {
        preId = $(tr.children()[0]).html();
    }
    else {
        preId = td.children().attr("origval");
    }
    
    //发送更新请求
    if ($(self).val() != $(self).attr("origval")) {
        //改变表格内容
        td.html($(self).val());

        //更新条目
        if (flag == 0) {
            //更新公司
            $.updateOneCompany(tr);
        }
        else {
            //更新学生
            $.updateOneStudent(preId, tr);
        }
    }
    else {
        //改变表格内容
        td.html($(self).val());
    }
};

$.addAutoComplete = function (dataSource) {
    //注册自动补全插件
    $("div.main div.cols#right div#rightTitle > input[type=text]").autocomplete({
        source: dataSource
    })
};

//生成初始表格
$.geneStuTable = function () {
    var innerHTML = "<tr><th>学号</th><th>姓名</th><th>密码</th><th>班级</th><th>入学时间</th><th>微信/QQ号</th><th>联系电话</th><th>所在企业</th></tr>";

    for (var i = 0; i < 10; i++) {
        if (i == 0) {
            innerHTML += "<tr class='chosen'>";
        }
        else {
            innerHTML += "<tr>";
        }

        for (var j = 0; j < 8; j++) {
            innerHTML += "<td></td>";
        }

        innerHTML += "</tr>";
    }

    $("table.info").html(innerHTML);
};