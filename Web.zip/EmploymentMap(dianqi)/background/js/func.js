/**
 * Created by zhy on 16/4/12.
 */
//右上角搜索
var rightInput, rightSpan;

//获取并显示数据
var tempData = [];
var tempKeys = [];
var dataSource = [];
var presentPageNum = 1;


//预加载右上角搜索内容
$(function () {
    rightInput = $("div#rightTitle input");
    rightSpan =  $($("div#rightTitle span")[1]);
});

var URL = "Job_Map/map_action.php";

$.geneByParentNodeAndId = function (parent, index, buttons) {
    var cols;
    var table = parent.children("table.info");


    //清空列表
    table.empty();

    switch (index) {
        case 0:
            cols = 8;
            
            table.nextAll("p").not("p.pages").remove();

            var spans = $("div#rightTitle span");
            if (spans.length == 1) {
                $(spans[0]).after(rightSpan);
                rightSpan.after(rightInput);
            }

            $("div.main div.quantity").remove();

            //标题
            parent.find("span.rightTitle").text("公司管理系统");

            //表格头
            table.html("<tr><th>编号</th><th>名称</th><th>省份</th><th>城市</th><th>性质</th><th>网址</th><th>是否推荐</th><th>学生数</th></tr>");

            //添加按钮
            if (table.nextAll().length == 0) {
                table.after(buttons);
                $.registerEvents();
            }
            
            break;

        case 1:
            cols = 8;

            table.nextAll("p").not("p.pages").remove();
            
            var spans = $("div#rightTitle span");
            if (spans.length == 1) {
                $(spans[0]).after(rightSpan);
                rightSpan.after(rightInput);
            }

            $("div.main div.quantity").remove();

            parent.find("span.rightTitle").text("学生管理系统");
            
            table.html("<tr><th>学号</th><th>姓名</th><th>密码</th><th>班级</th><th>入学时间</th><th>微信/QQ号</th><th>联系电话</th><th>所在企业</th></tr>");

            //添加按钮
            if (table.nextAll().length == 0) {
                table.after(buttons);
                $.registerEvents();
            }

            break;

        case 2:
            parent.find("span.rightTitle").text("批量导入");
            rightInput.remove();
            rightSpan.remove();

            //删除table后所有元素
            table.nextAll().remove();

            //添加文件选框
            table.after(
                "<div class='quantity' style='margin: 20px 0 0 5%'>" +
                "批量导入公司: " +
                "<form action='" + URL + "' enctype='multipart/form-data' method='POST'>" +
                "<input type='text' name='action' value='input_com' style='display: none'>" +
                "<input type='file' name='com'><input type='submit' name='submit' value='导入'>" +
                "</form>" +
                "批量导入学生: " +
                "<form action='" + URL + "' enctype='multipart/form-data' method='POST'>" +
                "<input type='text' name='action' value='input_stu' style='display: none'>" +
                "<input type='file' name='stu'><input type='submit' name='submit' value='导入'>" +
                "</form>" +
                "</div>" +
                // "<p>导入的文件类型必须是xls</p>" +
                // "<p>1、公司xls格式为</p>" +
                // "<p>公司编号  公司名称  所在省份  所在城市 公司属性  公司网页  是否重点  学生人数</p>" +
                // "<p>2、学生xls格式为</p>" +
                // "<p>学生编号  学生学号 学生姓名 入学时间 所在班级 微信|QQ 所在公司编号（如果没有可以为空）</p>" +
                // "<p>模版下载: </p>" +
                "<form action='" + URL + "' method='post'>" +
                "导出公司模版: " +
                "<input type='text' name='action' value='output_com_model' style='display: none'>" +
                "<a onclick='$(this).parent().submit()'>点击下载</a>" +
                "</form>" +
                "<form action='" + URL + "' method='post'>" +
                "导出学生模版: " +
                "<input type='text' name='action' value='output_stu_model' style='display: none'>" +
                "<a onclick='$(this).parent().submit()'>点击下载</a>" +
                "</form>");

            // alert("导入的文件类型必须是xls\n1、公司xls格式为\n公司编号  公司名称  所在省份  所在城市 公司属性  公司网页  是否重点  学生人数\n2、学生xls格式为\n学生编号  学生学号 学生姓名 入学时间 所在班级 微信|QQ 所在公司编号（如果没有可以为空）");

            break;

        case 3:
            parent.find("span.rightTitle").text("批量删除");
            rightInput.remove();
            rightSpan.remove();

            table.nextAll().remove();
            table.after(
                "<div class='quantity' style='margin: 20px 0 0 5%'>" +
                "按年级删除学生: " +
                "<form action='" + URL + "' method='post'>" +
                "<input type='text' name='action' value='del_grade_stu' style='display: none'>" +
                "<input type='text' name='grade' placeholder='输入年级'>" +
                "<input type='submit' value='删除'>" +
                "</form>" +
                "</div>");

            return;
            break;

        case 4:
            parent.find("span.rightTitle").text("批量导出");
            rightInput.remove();
            rightSpan.remove();

            table.nextAll().remove();
            table.after(
                "<div class='quantity' style='margin: 20px 0 0 5%'>" +
                "导出所有公司: " +
                "<form action='" + URL + "' method='post'><input type='text' name='action' value='output_com' style='display: none'><input type='submit' value='导出公司'></form>" +
                "导出所有学生: " +
                "<form action='" + URL + "' method='post'><input type='text' name='action' value='output_stu' style='display: none'><input type='submit' value='导出学生'></form>" +
                "导出所选公司的所有学生: " +
                "<form action='" + URL + "' method='post'><input type='text' name='action' value='output_stu_in_com' style='display: none'><input type='text' name='c_id' placeholder='公司名称'><input type='submit' value='导出学生'></form>" +
                "导出所填届学生的所有公司: " +
                "<form action='" + URL + "' method='post'><input type='text' name='action' value='output_com_has_stu' style='display: none'><input type='text' name='grade' placeholder='ex: 2013'><input type='submit' value='导出公司'></form>" +
                "</div>");


            //获得公司数据以进行自动补全
            $.getData("all_com", compKeys, undefined, function (source) {
                $("input[name=c_id]").autocomplete({
                    source: source
                })
            });


            //"导出所选公司的所有学生"提交前处理
            $("div.quantity form").submit(function (e) {
                if (this == $("div.quantity form")[2]) {
                    // e.preventDefault();

                    var input_com_id = $(this).children("input[name=c_id]");

                    input_com_id.val($.searchDataWithKey(input_com_id.val())[0][0]["c_id"]);
                }
            });
            
            break;

        default:
            break;
    }

    if (table.nextAll().length == 0) {
        table.after(tempItems);
    }

    //生成表格内容
    var tableRows = "";
    for (var i = 0; i < 10; i++) {
        if (i == 0) {
            tableRows += "<tr class='chosen'>";
        }
        else {
            tableRows += "<tr>";
        }

        for (var j = 0; j < cols; j++) {
            tableRows += "<td></td>"
        }

        tableRows += "</tr>";
    }

    var firstTR = table.find("tr");
    firstTR.after(tableRows);
};

//tr可选事件
$.chooseTR = function () {
    //table点击选中
    var tableTRs = $("div.main div.cols#right table.info tr");

    tableTRs.click(function () {
        if (this != tableTRs[0]) {
            var clicked = $(this);

            tableTRs.each(function () {
                if ($(this).hasClass("chosen")) {
                    $(this).removeClass("chosen");
                }

                clicked.addClass("chosen");
            })
        }
    })
};


//获取并显示数据
$.getAndShowData = function (action, keys, callBackWithSource) {
    $.getData(action, keys, function () {
        //显示数据
        $.showDataInTable(tempData[0], keys);

        //重置页码
        $("p.pages").html(1 + "/" + tempData.length);
    }, callBackWithSource);
};


$.getData = function (action, keys, showData, callBackWithSource) {
    tempData = [];
    tempKeys = [];
    dataSource = [];
    presentPageNum = 1;

    $.post(URL, {
        "action": action
    }, function (data) {
        // alert(data);
        data = eval("(" + data + ")");

        //保留当前键值
        tempKeys = keys;

        //切割数据
        $.divideData(data, [keys[0], keys[1]], dataSource);

        //显示数据
        if (typeof (showData) != "undefined") {
            showData();
        }

        //附加操作
        callBackWithSource(dataSource);
    });
};


//切割数据
$.divideData = function (data, keys, dataSource) {
    var dataArray = [];

    $(data).each(function (index) {
        var item = $(this);

        dataArray.push(item);

        //添加至dataSource
        $(keys).each(function () {
            dataSource.push(item[0][this]);
        });

        if ((index + 1) % 10 == 0) {
            tempData.push(dataArray);
            dataArray = [];
        }
    });

    if (dataArray.length < 10) {
        tempData.push(dataArray);
    }
};

//显示数据
$.showDataInTable = function (data, keys) {
    if (typeof (keys) == "undefined") {
        keys = tempKeys;
    }
    
    var trs = $("div.main table.info tr");

    $.each(data, function (index, value) {
        var tds = $(trs[index + 1]).children("td");

        tds.each(function (tdIndex) {
            $(this).html(value[0][keys[tdIndex]]);
        })
    });

    if (data.length < 10) {
        for (var i = data.length; i < 10; i++) {
            var tds = $(trs[i + 1]).children("td");

            tds.each(function () {
                $(this).html("");
            })
        }
    }
};

//改变页数
$.increasePageNum = function (p) {
    if (presentPageNum < tempData.length) {
        presentPageNum++;
    }

    p.html((presentPageNum) + "/" + tempData.length);

    $.showDataInTable(tempData[presentPageNum - 1], tempKeys);
};

$.decreasePageNum = function (p) {
    if (presentPageNum > 1) {
        presentPageNum--;
    }

    p.html((presentPageNum) + "/" + tempData.length);

    $.showDataInTable(tempData[presentPageNum - 1], tempKeys);
};


//更新学生
$.updateOneStudent = function (preId, tr, callBack) {
    var tds = tr.children("td");
    var compId = 0;

    if ($(tds[7]).html() != "") {
        compId = $.searchDataWithKey($(tds[7]).html())[0][0]["c_id"];
    }

    $.post(URL, {
        "action": "up_one_stu",
        "pre_stu_id": preId,
        "new_stu_id": $(tds[0]).html(),
        "stu_name": $(tds[1]).html(),
        "pwd": $(tds[2]).html(),
        "stu_class": $(tds[3]).html(),
        "graduate_time": $(tds[4]).html(),
        "weixin_qq": $(tds[5]).html(),
        "phone": $(tds[6]).html(),
        "com_id": compId
    }, function (data) {
        if (typeof (callBack) != "undefined") {
            callBack(data);
        }

        if (data > 0) {
            $.getData("get_all_stu", stuKeys, undefined, function (source) {
                $.addAutoComplete(source);
            })
        }
        else {
            alert("遇到问题, 请重试");
        }
    })
};

//更新公司
$.updateOneCompany = function (tr, callBack) {
    var tds = tr.children("td");

    $.post(URL, {
        "action": "up_one_com",
        "c_id": $(tds[0]).html(),
        "c_name": $(tds[1]).html(),
        "c_province": $(tds[2]).html(),
        "c_city": $(tds[3]).html(),
        "c_property": $(tds[4]).html(),
        "c_website": $(tds[5]).html(),
        "is_vital": $(tds[6]).html(),
        "stu_num": $(tds[7]).html()
    }, function (data) {
        //更新回调
        // data = eval("(" + data + ")");
        if (typeof (callBack) != "undefined") {
            callBack(data);
        }

        if (data > 0) {
            $.getData("all_com", compKeys, undefined, function (source) {
                $.addAutoComplete(source);
            })
        }
        else {
            alert("遇到问题, 请重试");
        }
    })
};

//搜索数据
$.searchDataWithKey = function (key) {
    var result = [];

    $(dataSource).each(function (index) {
        if (this == key) {
            if (index % 2 != 0) {
                result.push($(tempData[Math.floor(index / 2 / 10)][Math.floor((index - 1) / 2) % 10]));
            }
            else {
                result.push($(tempData[Math.floor(index / 2 / 10)][index / 2 % 10]));
            }
            
            return false;
        }
    });

    return result;
};


//删除条目

//删除公司
$.deleteCompany = function (id) {
    $.post(URL, {
        "action": "del_com",
        "com_id": id
    }, function (data) {
        //数据库删除成功
        // data = eval("(" + data + ")");

        if (data > 0) {
            alert("删除成功");

            //重新申请数据
            $.getAndShowData("all_com", compKeys, function (source) {
                $.addAutoComplete(source);
            })
        }
        else {
            alert("遇到问题, 请重试");
        }
    })
};

//删除学生
$.deleteStudent = function (id) {
    $.post(URL, {
        "action": "del_stu",
        "stu_id": id
    }, function (data) {
        //数据库删除成功
        if (data > 0) {
            alert("删除成功");

            //重新申请数据
            $.getAndShowData("get_all_stu", stuKeys, function (source) {
                $.addAutoComplete(source);
            })
        }
        else {
            alert("遇到问题, 请重试");
        }
    })
};

//插入公司
$.insertCompany = function (callBack) {
    $.post(URL, {
        "action": "inser_com"
    }, function (data) {
        if (data > 0) {
            // alert("插入成功! 请对新插入的条目进行进一步修改");

            //重新申请数据
            $.getData("all_com", compKeys, undefined, function () {
                //页码
                $.goToLastPage($("p.pages"));

                //进一步操作
                callBack();
            })
        }
        else {
            alert("遇到问题,请重试");
        }
    })
};

//插入学生
$.insertStudent = function (callBack) {
    $.post(URL, {
        "action": "inser_stu"
    }, function (data) {
        if (data > 0) {
            // alert("插入成功! 请对新插入的条目进行进一步修改");
            
            //重新申请数据
            $.getData("get_all_stu", stuKeys, undefined, function () {
                //页码
                $.goToLastPage($("p.pages"));
                
                //进一步操作
                callBack();
            })
        }
        else {
            alert("遇到问题,请重试");
        }
    })
};

//跳至最后一页
$.goToLastPage = function (p) {
    if (tempData.length == 0) {
        $.showDataInTable(tempData[tempData.length - 1], tempKeys);
    }
    else {
        if (tempData[tempData.length - 1].length != 0) {
            $.showDataInTable(tempData[tempData.length - 1], tempKeys);
        }
        else {
            $.showDataInTable(tempData[tempData.length - 2], tempKeys);
        }
    }

    presentPageNum = tempData.length;
    p.html(tempData.length + "/" + tempData.length);
};

$.goToPointedPage = function (page) {
    if (tempData.length != 0) {
        $.showDataInTable(tempData[page - 1], tempKeys);
        presentPageNum = page;

        return page + "/" + tempData.length;
    }
    else {
        return "0/0";
    }
};