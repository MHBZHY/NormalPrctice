/**
 * Created by zhy on 16/3/25.
 */


$.createAndAddAnnotation = function (map, locationName, title, zoomLevel, didFinishGetPoint) {
    $.createAnnotation(map, locationName, title, zoomLevel, undefined, function (marker, point) {
        didFinishGetPoint(marker, point);
        map.addOverlay(marker);
    });
};

$.createAnnotation = function (map, locationName, title, zoomLevel, afterGetPoint, didFinish) {
    // 创建地址解析器实例
    var myGeo = new BMap.Geocoder();
    // 将地址解析结果显示在地图上,并调整地图视野
    myGeo.getPoint(locationName, function (point) {
        if (point) {
            //添加窗口信息
            var marker = new BMap.Marker(point);  // 创建标注
            // map.addOverlay(marker);              // 将标注添加到地图中
            // alert(point);

            if (typeof (afterGetPoint) != "undefined") {
                marker = afterGetPoint(marker, point);
            }

            var label = new BMap.Label(locationName, {offset: new BMap.Size(20, -12)});
            marker.setLabel(label);

            var opts = {
                width: 260,     // 信息窗口宽度
                height: 90,     // 信息窗口高度
                title: title, // 信息窗口标题
                enableMessage: false//设置允许信息窗发送短息
                // message: "亲耐滴，晚上一起吃个饭吧？戳下面的链接看下地址喔~"
            };

            var infoWindow = new BMap.InfoWindow("", opts);  // 创建信息窗口对象

            $(marker).click(function () {
                map.openInfoWindow(infoWindow, point);
            });
            marker.addEventListener("click", function () {
                map.openInfoWindow(infoWindow, point);
            });


            if (typeof (didFinish) != "undefined") {
                didFinish(marker, point);
            }
        }
        else {
            // alert("您选择地址没有解析到结果!");

            return 0;
        }
    }, "北京市");
};


// $.createAndAddAnnotationWithPoint = function (map, name, point, title, zoomLevel, afterGetPoint, didFinish) {
//     $.createAnnotationWithPoint(map, name, point, title, zoomLevel, afterGetPoint, function (marker, point) {
//         didFinish(marker, point);
//         map.addOverlay(marker);
//     });
// };

$.createAnnotationWithPoint = function (map, name, point, title, zoomLevel, afterGetPoint, didFinish) {
    //添加窗口信息
    var marker = new BMap.Marker(point);  // 创建标注
    // map.addOverlay(marker);              // 将标注添加到地图中
    // alert(point);

    marker = afterGetPoint(marker, point);

    var label = new BMap.Label(name, {offset: new BMap.Size(20, -12)});
    marker.setLabel(label);

    var opts = {
        width: 260,     // 信息窗口宽度
        height: 90,     // 信息窗口高度
        title: title, // 信息窗口标题
        enableMessage: false//设置允许信息窗发送短息
        // message: "亲耐滴，晚上一起吃个饭吧？戳下面的链接看下地址喔~"
    };

    var infoWindow = new BMap.InfoWindow("", opts);  // 创建信息窗口对象
    
    $(marker).click(function () {
        map.openInfoWindow(infoWindow, point);
    });
    marker.addEventListener("click", function () {
        map.openInfoWindow(infoWindow, point);
    });


    didFinish(marker, point);
};

//清除指定大头针
$.clearMarkers = function (map, infos) {
    $.each(infos, function (index, value) {
        if (value.marker != null) {
            if (typeof(value.marker) != "undefined") {
                map.removeOverlay(value.marker);
            }
        }
    })
};

$.addMarkers = function (map, infos) {
    $.each(infos, function (index, value) {
        if (value.marker != null) {
            if (typeof(value.marker) != "undefined") {
                var label = new BMap.Label(value.name, {offset: new BMap.Size(20, -12)});
                value.marker.setLabel(label);

                map.addOverlay(value.marker);
            }
        }
    })
};

$.addBackButton = function (map, buttonText, buttonAction) {
    function ZoomControl() {
        // 默认停靠位置和偏移量
        this.defaultAnchor = BMAP_ANCHOR_TOP_LEFT;
        this.defaultOffset = new BMap.Size(10, 10);
    }

    ZoomControl.prototype = new BMap.Control();

    ZoomControl.prototype.initialize = function (map) {
        var div = document.createElement("div");

        div.appendChild(document.createTextNode("返回"));

        div.style.cursor = "pointer";
        div.style.border = "1px solid gray";
        div.style.backgroundColor = "white";

        div.onclick = buttonAction;

        map.getContainer().appendChild(div);

        return div;
    };

    var myControl = new ZoomControl();

    map.addControl(myControl);
};