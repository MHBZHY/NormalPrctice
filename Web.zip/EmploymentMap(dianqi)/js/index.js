/**
 * Created by zhy on 16/3/29.
 */
document.write('<script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=gNXrRmEp65WpvCGWmgtX6DMTurGOgksY"></script>');


var provinceZoomLevel = 7;
var cityZoomLevel = 11;
var companyZoomLevel = 16;

var provInfos = new Array();
var cityInfos = new Array();
var compInfos = new Array();

var compNames = new Array();

var presentZoomLevel = 0;

$(document).ready(function () {
    var map = new BMap.Map("map");    // 创建Map实例
    map.centerAndZoom(new BMap.Point(116.404, 39.915), 6);  // 初始化地图,设置中心点坐标和地图级别
    map.addControl(new BMap.MapTypeControl());   //添加地图类型控件
    map.setCurrentCity("北京");          // 设置地图显示的城市 此项是必须设置的
    map.enableScrollWheelZoom(true);     //开启鼠标滚轮缩放


    $.addBackButton(map, "点击返回最初的缩放等级及位置", function () {
        map.centerAndZoom(new BMap.Point(116.404, 39.915), 6);
    });


    //获取省大头针
    $.post(URL, {
        "action": "province"
    }, function (data) {
        var jsonPro = eval("(" + data + ")");

        $.each(jsonPro, function (index, value) {
            $.createAndAddAnnotation(
                map,
                value.province, 
                value.province,
                provinceZoomLevel,
                function (marker, point) {
                    provInfos[provInfos.length] = {
                        "marker": marker,
                        "id": value.pro_id,
                        "name": value.province
                    }
                });
        })
    });

    //获取市/区大头针
    $.post(URL, {
        "action": "city"
    }, function (data) {
        var jsonCity = eval("(" + data + ")");

        $.each(jsonCity, function (index, value) {
            $.createAnnotation(
                map,
                value.city_name, 
                value.city_name, 
                cityZoomLevel,
                undefined,
                function (marker, point) {
                    cityInfos[cityInfos.length] = {
                        "marker": marker,
                        "id": value.city_id,
                        "name": value.city_name
                    }
                });
        })
    });


    //获取公司大头针
    $.post(URL, {
        "action": "all_com"
    }, function (data) {
        var jsonComp = eval("(" + data + ")");


        //遍历数据
        $.each(jsonComp, function (index, value) {
            //信息框内容
            var title = '<span style="display: block;">' + value.c_name + '</span>' +
                '<span style="display: block;">性质:' + value.c_property + '</span>' +
                '<span style="display: block;">网址:<a href="' + value.c_website + '">' + value.c_website + '</a></span>';

            //判断经纬度
            if (value.lng == null || value.lng == 0) {
                $.createAnnotation(
                    map,
                    value.c_name,
                    title,
                    companyZoomLevel,
                    function (marker, point) {
                        if (value.is_vital == "1") {
                            var icon = new BMap.Icon("http://ee.bjtu.edu.cn/EmploymentMap/img/star.png", new BMap.Size(30, 30));
                            return new BMap.Marker(point, {icon: icon});
                        }
                        else {
                            return marker;
                        }
                    },
                    function (marker, point) {
                        compInfos[compInfos.length] = {
                            "marker": marker,
                            "id": value.c_id,
                            "name": value.c_name,
                            "property": value.c_property,
                            "website": value.c_website,
                            "is_vital": value.is_vital,
                            "point": point
                        };

                        //添加公司名称到数组
                        compNames.push(value.c_name);
                    }
                )
            }
            else {
                $.createAnnotationWithPoint(
                    map,
                    value.c_name,
                    new BMap.Point(value.lng, value.lat),
                    title,
                    companyZoomLevel,
                    function (marker, point) {
                        if (value.is_vital == "1") {
                            var icon = new BMap.Icon("http://ee.bjtu.edu.cn/EmploymentMap/img/star.png", new BMap.Size(30, 30));
                            return new BMap.Marker(point, {icon: icon});
                        }
                        else {
                            return marker;
                        }
                    },
                    function (marker, point) {
                        compInfos[compInfos.length] = {
                            "marker": marker,
                            "id": value.c_id,
                            "name": value.c_name,
                            "property": value.c_property,
                            "website": value.c_website,
                            "is_vital": value.is_vital,
                            "point": point
                        };

                        //添加公司名称到数组
                        compNames.push(value.c_name);
                    }
                )
            }
        });


        //填充学生信息
        $.post(URL, {
            "action": "get_stu"
        }, function (data) {
            var jsonData = eval("(" + data + ")")[0];
            var tds = $("div.sub#user table.info").find("td").not(".head");


            $(tds[0]).html(jsonData["stu_name"]);
            $(tds[1]).html(jsonData["stu_id"]);
            $(tds[2]).html(jsonData["stu_class"]);
            $(tds[3]).html(jsonData["graduate_time"]);
            $(tds[4]).html(jsonData["weixin_qq"]);
            $(tds[5]).html(jsonData["phone"]);

            $(compNames).each(function (index, value) {
                if (index == jsonData["com_id"]) {
                    $(tds[6]).html(value);
                    return false;
                }
            })
        });


        //设置数据源
        $("div.sub div.title input.text").autocomplete({
            source: compNames
        });
    });


    //搜索公司
    var textLabel = $("div.sub div.title input.text");

    $("div.sub div.title input.submit").click(function () {
        $(compInfos).each(function () {
            if (this.name == textLabel.val()) {
                map.centerAndZoom(this.point, companyZoomLevel);
                $(this.marker).trigger("click");
                // this.marker.click();
            }
        })
    });


    //完成缩放后执行
    map.addEventListener("zoomend", clearMarker, false);


//删除地标
    function clearMarker() {

        if (map.getZoom() >= cityZoomLevel
            && !(presentZoomLevel >= cityZoomLevel)) {
            // $.clearMarkerWithLabel(map, "省");
            // $.clearMarkerWithLabel(map, "区");
            $.clearMarkers(map, provInfos);
            $.clearMarkers(map, cityInfos);

            $.addMarkers(map, compInfos);

            //清除公司
        }
        else if (map.getZoom() < cityZoomLevel && map.getZoom() >= provinceZoomLevel
            && !(presentZoomLevel < cityZoomLevel && presentZoomLevel >= provinceZoomLevel)) {
            // $.clearMarkerWithLabel(map, "区");
            // $.clearMarkerWithLabel(map, "市");
            $.clearMarkers(map, provInfos);
            $.clearMarkers(map, compInfos);

            $.addMarkers(map, cityInfos);
            //清除公司
        }
        else if (map.getZoom() < provinceZoomLevel
            && !(presentZoomLevel < provinceZoomLevel)) {
            $.clearMarkers(map, compInfos);
            $.clearMarkers(map, cityInfos);

            $.addMarkers(map, provInfos);
        }

        presentZoomLevel = map.getZoom();
    }

    //学生信息边栏可调节大小
    $("#user").resizable({
        minWidth: 330
    });
    
    $("#user").resize(function () {
        $("#map").width($(this).parent().width() - $(this).width());
    })
});
